alter table TB_Usuario add TX_DeviceId varchar(255)
alter table TB_Usuario add TX_DeviceType varchar(50)