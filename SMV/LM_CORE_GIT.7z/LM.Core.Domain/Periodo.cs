﻿
namespace LM.Core.Domain
{
    public class Periodo
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public short FatorConversaoDia { get; set; }
    }
}
