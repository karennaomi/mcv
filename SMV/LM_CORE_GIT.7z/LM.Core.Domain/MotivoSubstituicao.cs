﻿namespace LM.Core.Domain
{
    public class MotivoSubstituicao
    {
        public int Id { get; set; }
        public string Motivo { get; set; }
        public bool Ativo { get; set; }
    }
}
