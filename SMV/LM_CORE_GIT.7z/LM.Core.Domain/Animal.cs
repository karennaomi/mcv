﻿namespace LM.Core.Domain
{
    public class Animal
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public bool Ativo { get; set; }
    }
}
