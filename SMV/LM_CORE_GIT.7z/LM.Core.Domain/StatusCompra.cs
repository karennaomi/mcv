﻿
namespace LM.Core.Domain
{
    public enum StatusCompra : short
    {
        ItemAComprar = 0,
        Comprado = 1,
        AgoraNao = 2,
        NaoEncontrado = 3,
        ItemSubstituido = 4
    }
}
