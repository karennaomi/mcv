﻿
namespace LM.Core.Domain
{
    public enum StatusPedido
    {
        Pendente = 1,
        Rejeitado = 2,
        Comprado = 3,
        Substituido = 4,
        ExcluidoPeloUsuario = 99
    }
}
