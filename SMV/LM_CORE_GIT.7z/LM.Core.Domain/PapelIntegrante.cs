﻿
namespace LM.Core.Domain
{
    public enum PapelIntegrante
    {
        Administrador = 1,
        Colaborador = 2
    }
}
