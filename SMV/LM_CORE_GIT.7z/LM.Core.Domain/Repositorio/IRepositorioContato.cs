﻿
namespace LM.Core.Domain.Repositorio
{
    public interface IRepositorioContato
    {
        Contato Criar(Contato contato);
    }
}
