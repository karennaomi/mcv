﻿
namespace LM.Core.Domain.Repositorio
{
    public interface IRepositorioFilaItem
    {
        FilaItem Criar(FilaItem filaItem);
    }
}
