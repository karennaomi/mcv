﻿namespace LM.Core.Domain.Repositorio
{
    public interface IRepositorioContrato
    {
        Contrato ObterAtivo();
    }
}
