﻿
namespace LM.Core.Domain.Repositorio
{
    public interface IRepositorioLojaFavorita
    {
        Loja VerificarLojaExistente(Loja loja);
    }
}
