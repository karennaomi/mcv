﻿
namespace LM.Core.Domain
{
    public enum TipoPontoDemanda
    {
        Casa = 1,
        Campo = 2,
        Praia = 3
    }
}
