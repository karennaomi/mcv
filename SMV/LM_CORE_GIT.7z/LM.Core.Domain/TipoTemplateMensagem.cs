﻿namespace LM.Core.Domain
{
    public enum TipoTemplateMensagem
    {
        Indefinido = 0,
        AtivarCompra = 1,
        DesativarCompra = 2,
        PedidoItemCriado = 3,
        RecuperarSenha = 4,
        ConviteIntegrante = 5,
        FinalizarCompra = 6,
        CadastroCompleto = 7
    }
}
