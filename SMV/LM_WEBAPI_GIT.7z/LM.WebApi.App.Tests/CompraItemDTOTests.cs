﻿using System.Runtime.Remoting.Messaging;
using LM.Core.Domain;
using LM.WebApi.DTO;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;

namespace LM.WebApi.App.Tests
{
    [TestFixture]
    public class CompraItemDTOTests
    {
        [Test]
        public void OrdemCorreta()
        {
            var itens = new List<CompraItemDTO>
            {
                new CompraItemDTO{ Id = 1, Item = new ItemDTO{ Produto = GetProduto("Morango", "Frutas"), EhEssencial = true, Tipo = ItemTipoDTO.Lista}},
                new CompraItemDTO{ Id = 2, Item = new ItemDTO{ Produto = GetProduto("Abacaxi", "Frutas"), EhEssencial = false, Tipo = ItemTipoDTO.Pedido}},
                new CompraItemDTO{ Id = 3, Item = new ItemDTO{ Produto = GetProduto("Pera", "Frutas"), EhEssencial = false, Tipo = ItemTipoDTO.Lista}},
                new CompraItemDTO{ Id = 4, Item = new ItemDTO{ Produto = GetProduto("Figo", "Frutas"), EhEssencial = false, Tipo = ItemTipoDTO.Pedido}},
                new CompraItemDTO{ Id = 5, Item = new ItemDTO{ Produto = GetProduto("Uva", "Frutas"), EhEssencial = true, Tipo = ItemTipoDTO.Lista}},
                new CompraItemDTO{ Id = 6, Item = new ItemDTO{ Produto = GetProduto("Peixe", "Carnes"), EhEssencial = false, Tipo = ItemTipoDTO.Lista}},
                new CompraItemDTO{ Id = 7, Item = new ItemDTO{ Produto = GetProduto("Frango", "Carnes"), EhEssencial = false, Tipo = ItemTipoDTO.Pedido}},
                new CompraItemDTO{ Id = 8, Item = new ItemDTO{ Produto = GetProduto("Boi", "Carnes"), EhEssencial = true, Tipo = ItemTipoDTO.Lista}},
                new CompraItemDTO{ Id = 9, Item = new ItemDTO{ Produto = GetProduto("Carangueijo", "Carnes"), EhEssencial = true, Tipo = ItemTipoDTO.Lista}},
                new CompraItemDTO{ Id = 10, Item = new ItemDTO{ Produto = GetProduto("Carangueijo", "Carnes"), EhEssencial = false, Tipo = ItemTipoDTO.Pedido}},
            };

            var itensOrdenados = itens.BlasterOrder().ToList();
            Assert.AreEqual(8, itensOrdenados[0].Id);
            Assert.AreEqual(9, itensOrdenados[1].Id);
            Assert.AreEqual(10, itensOrdenados[2].Id);
            Assert.AreEqual(7, itensOrdenados[3].Id);
            Assert.AreEqual(6, itensOrdenados[4].Id);
            Assert.AreEqual(2, itensOrdenados[5].Id);
            Assert.AreEqual(4, itensOrdenados[6].Id);
            Assert.AreEqual(1, itensOrdenados[7].Id);
            Assert.AreEqual(3, itensOrdenados[8].Id);
            Assert.AreEqual(5, itensOrdenados[9].Id);
        }

        [Test]
        public void CompraItemRespondeParaQuantidadeTotal()
        {
            var compraItem = new CompraItemDTO
            {
                Item = new ItemDTO(new ListaItem {QuantidadeDeSugestaoDeCompra = 1}, 0, 0, "")
            };
            Assert.IsInstanceOf<decimal>(compraItem.QuantidadeTotal);
        }

        [Test]
        public void QuantidadeTotalSomaQuantidadeSugeridaDoItemPrincipalEProdutosSemelhantes()
        {
            var compraItem = new CompraItemDTO
            {
                Item = new ItemDTO(new ListaItem{QuantidadeDeSugestaoDeCompra = 3}, 0, 0, ""),
                ItensComProdutosSemelhantes = new List<CompraItemDTO>
                {
                    new CompraItemDTO{ Item = new ItemDTO(new PedidoItem{QuantidadeSugestaoCompra = 1}, 0, 0, "")},
                    new CompraItemDTO{ Item = new ItemDTO(new PedidoItem{QuantidadeSugestaoCompra = 2}, 0, 0, "")}
                }
            };
            Assert.AreEqual(6, compraItem.QuantidadeTotal);
        }

        [Test]
        public void QuantidadeTotalSomaQuantidadeSugeridaDoItemPrincipalEProdutosSemelhantesMesmoComListaDeSemelhantesNula()
        {
            var compraItem = new CompraItemDTO
            {
                Item = new ItemDTO(new ListaItem { QuantidadeDeSugestaoDeCompra = 3 }, 0, 0, "")
            };
            Assert.AreEqual(3, compraItem.QuantidadeTotal);
        }

        [Test]
        public void CompraItemRespondeParaQuantidadeTotalDePedidos()
        {
            var compraItem = new CompraItemDTO{ Item = new ItemDTO(new ListaItem{ QuantidadeDeSugestaoDeCompra = 2}, 0, 0, "")};
            Assert.IsInstanceOf<decimal>(compraItem.QuantidadeTotalDePedidos);
        }

        [Test]
        public void CompraItemComItemDeDespensaEPedidosSemelhantesDeveMostrarQuantidadeTotalDePedidosCorretamente()
        {
            var compraItem = new CompraItemDTO
            {
                Item = new ItemDTO(new ListaItem { QuantidadeDeSugestaoDeCompra = 3 }, 0, 0, ""),
                ItensComProdutosSemelhantes = new List<CompraItemDTO>
                {
                    new CompraItemDTO{ Item = new ItemDTO(new PedidoItem{QuantidadeSugestaoCompra = 4}, 0, 0, "")},
                    new CompraItemDTO{ Item = new ItemDTO(new PedidoItem{QuantidadeSugestaoCompra = 2}, 0, 0, "")}
                }
            };
            Assert.AreEqual(6, compraItem.QuantidadeTotalDePedidos);
        }

        [Test]
        public void CompraItemSomentePedidosDeveMostrarQuantidadeTotalDePedidosCorretamente()
        {
            var compraItem = new CompraItemDTO
            {
                Item = new ItemDTO(new PedidoItem { QuantidadeSugestaoCompra = 2 }, 0, 0, ""),
                ItensComProdutosSemelhantes = new List<CompraItemDTO>
                {
                    new CompraItemDTO{ Item = new ItemDTO(new PedidoItem{QuantidadeSugestaoCompra = 1}, 0, 0, "")},
                    new CompraItemDTO{ Item = new ItemDTO(new PedidoItem{QuantidadeSugestaoCompra = 2}, 0, 0, "")}
                }
            };
            Assert.AreEqual(5, compraItem.QuantidadeTotalDePedidos);
        }

        private static ProdutoDTO GetProduto(string nome, string secao)
        {
            return new ProdutoDTO {Nome = nome, Categoria = new CategoriaDTO {Secao = new CategoriaDTO {Nome = secao}}};
        }
    }
}
