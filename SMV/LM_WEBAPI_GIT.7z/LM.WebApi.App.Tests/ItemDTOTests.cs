﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LM.Core.Domain;
using LM.WebApi.DTO;
using Moq;
using NUnit.Framework;

namespace LM.WebApi.App.Tests
{
    [TestFixture]
    public class ItemDTOTests
    {
        [Test]
        public void ValorDoEstoqueEstimadoComUmaCasaDecimal()
        {
            var item = new ItemDTO(new ListaItem {QuantidadeDoEstoqueEstimado = 2.36585M}, 0, 0, "");
            Assert.AreEqual(2.3M, item.QuantidadeEstoqueEstimado);
        }

        [Test]
        public void ValorDoEstoqueComUmaCasaDecimal()
        {
            var item = new ItemDTO {QuantidadeEstoque = 2.6558415M};
            Assert.AreEqual(2.6M, item.QuantidadeEstoque);
        }

        [Test]
        public void ValorSugeridoDeCompraDeveSerInteiroParaCima()
        {
            var itemMock = new Mock<IItem>();
            itemMock.Setup(i => i.ObterQuantidadeParaCompra()).Returns(3.51454M);
            var item = new ItemDTO(itemMock.Object, 0, 0, "");
            Assert.AreEqual(4, item.QuantidadeSugestaoCompra);
        }

        [Test]
        public void ValorSugeridoDeCompraDeveSerInteiroParaBaixo()
        {
            var itemMock = new Mock<IItem>();
            itemMock.Setup(i => i.ObterQuantidadeParaCompra()).Returns(3.4934435M);
            var item = new ItemDTO(itemMock.Object, 0, 0, "");
            Assert.AreEqual(3, item.QuantidadeSugestaoCompra);
        }
    }
}
