﻿
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Owin.Testing;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace LM.WebApi.App.Tests
{
    public abstract  class BaseAuthenticatedTests : BaseTestServer
    {
        protected virtual string Username { get { return "joe@mail.com"; } }
        protected virtual string Password { get { return "123456"; } }

        private string _token;

        protected override void PostSetup(TestServer server)
        {
            var tokenDetails = new List<KeyValuePair<string, string>>()
            {
                new KeyValuePair<string, string>("grant_type", "password"),
                new KeyValuePair<string, string>("username", Username),
                new KeyValuePair<string, string>("password", Password),
                new KeyValuePair<string, string>("client_id", "test_app"),
                new KeyValuePair<string, string>("client_secret", "BE3C6F91C047404BB2596028AB55D638")
            };

            var tokenPostData = new FormUrlEncodedContent(tokenDetails);
            var tokenResult = server.HttpClient.PostAsync("/api/token", tokenPostData).Result;
            Assert.AreEqual(HttpStatusCode.OK, tokenResult.StatusCode);

            var body = JObject.Parse(tokenResult.Content.ReadAsStringAsync().Result);

            _token = (string)body["access_token"];
        }

        protected override async Task<HttpResponseMessage> GetAsync()
        {
            return await CreateRequest(Uri).GetAsync();
        }

        protected override async Task<HttpResponseMessage> PostAsync<TModel>(TModel model)
        {
            return await CreateRequest(Uri)
            .And(request => request.Content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json"))
            .PostAsync();
        }

        protected override async Task<HttpResponseMessage> DeleteAsync(object id)
        {
            return await CreateRequest(Uri + "/" + id).SendAsync(HttpMethod.Delete.ToString());
        }

        private RequestBuilder CreateRequest(string uri)
        {
            return Server.CreateRequest(Uri)
                .AddHeader("Content-Type", "application/json")
                .AddHeader("Authorization", "Bearer " + _token);
        }
    }
}
