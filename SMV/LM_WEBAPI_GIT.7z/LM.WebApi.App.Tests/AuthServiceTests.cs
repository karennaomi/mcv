﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using LM.Core.Domain;
using LM.Core.Domain.CustomException;
using LM.Core.RepositorioEF;
using LM.WebApi.App.AuthContext;
using LM.WebApi.App.Models;
using Microsoft.Owin.Security;
using Moq;
using NUnit.Framework;
using LM.Core.Application;
using LM.Core.Domain.Repositorio;
using NUnit.Framework.Constraints;

namespace LM.WebApi.App.Tests
{
    [TestFixture]
    public class AuthServiceTests
    {
        [Test]
        public void ClientIdVazioThrowsException()
        {
            var authService = GetService();
            var exception = Assert.Throws<InvalidContextException>(() => authService.AuthClient("", ""));
            Assert.AreEqual("client_id", exception.Key);
            Assert.AreEqual("client_id precisa ser enviado.", exception.Message);
        }

        [Test]
        public void ClientIdNaoEncontradoThrowsException()
        {
            var authService = GetService();
            var exception = Assert.Throws<InvalidContextException>(() => authService.AuthClient("test_app", "123456"));
            Assert.AreEqual("client_id", exception.Key);
            Assert.AreEqual("Cliente 'test_app' não cadastrado no sistema.", exception.Message);
        }

        [Test]
        public void AppClientNativeWithoutSecretThrowsException()
        {
            var authService = GetService(GetAppClient(AppTypes.NativeConfidential));
            var exception = Assert.Throws<InvalidContextException>(() => authService.AuthClient("test_app", ""));
            Assert.AreEqual("client_secret", exception.Key);
            Assert.AreEqual("client_secret precisa ser enviado.", exception.Message);
        }

        [Test]
        public void AppClientNativeSecretNotEqualDatabaseSecretThrowsException()
        {
            var authService = GetService(GetAppClient(AppTypes.NativeConfidential));
            var exception = Assert.Throws<InvalidContextException>(() => authService.AuthClient("test_app", "zxcvbn"));
            Assert.AreEqual("client_secret", exception.Key);
            Assert.AreEqual("client_secret inválido.", exception.Message);
        }

        [Test]
        public void AppClientDesativadoThrowsException()
        {
            var authService = GetService(GetAppClient(AppTypes.NativeConfidential, false));
            var exception = Assert.Throws<InvalidContextException>(() => authService.AuthClient("test_app", "qwerty"));
            Assert.AreEqual("client_id", exception.Key);
            Assert.AreEqual("Cliente desativado.", exception.Message);
        }

        [Test]
        public void UsuarioInvalidoNaGeracaoDoTicketLancaException()
        {
            var authService = GetService(GetAppClient(AppTypes.NativeConfidential, false));
            Assert.Throws<LoginInvalidoException>(() => authService.CreateAuthTicket("usuario@invalido.com", "123456", "Bearer", "web_app"));
        }

        [Test]
        public void GeraTicketValido()
        {
            var usuario = GetUsuario();
            var pontoDemanda = GetPontoDemanda(1234);
            
            var authService = GetService(GetAppClient(AppTypes.NativeConfidential, false));
            var ticket = authService.CreateAuthTicket(usuario.Login, "123789", "Bearer", _clientId);
            Assert.AreEqual(usuario.Id.ToString(), ticket.Identity.Claims.Single(c => c.Type == LMClaimTypes.UsuarioId).Value);
            Assert.AreEqual(pontoDemanda.Id.ToString(), ticket.Identity.Claims.Single(c => c.Type == LMClaimTypes.PontoDemandaId).Value);
            Assert.AreEqual(usuario.Integrante.Email, ticket.Properties.Dictionary["user_email"]);
            Assert.AreEqual(usuario.Integrante.Nome, ticket.Properties.Dictionary["user_name"]);
        }

        [Test]
        public void PontoDemandaVazioInvalidoLancaException()
        {
            var authService = GetService(GetAppClient(AppTypes.NativeConfidential, false));
            Assert.Throws<PontoDemandaInvalidoException>(() => authService.RenewAuthTicket(new AuthenticationTicket(new ClaimsIdentity(), new AuthenticationProperties()), null));
        }

        [Test]
        public void PontoDemandaQueNaoPertenceAoUsuarioLancaException()
        {
            var usuario = GetUsuario();
            var authService = GetService(GetAppClient(AppTypes.NativeConfidential, false));
            var ticket = authService.CreateAuthTicket(usuario.Login, "123789", "Bearer", _clientId);
            Assert.Throws<PontoDemandaInvalidoException>(() => authService.RenewAuthTicket(ticket, "7777"));
        }

        [Test]
        public void RenovaOTicket()
        {
            var usuario = GetUsuario();
            var authService = GetService(GetAppClient(AppTypes.NativeConfidential, false));
            var ticket = authService.CreateAuthTicket(usuario.Login, "123789", "Bearer", _clientId);
            var renewedTicket = authService.RenewAuthTicket(ticket, "9876");
            Assert.AreEqual(3, ticket.Identity.Claims.Count());
            Assert.AreEqual("9876", renewedTicket.Identity.Claims.Single(c => c.Type == LMClaimTypes.PontoDemandaId).Value);
        }

        private const string _clientId = "test_app";
        private static AuthProviderService GetService(AppClient client = null)
        {
            var service = new AuthProviderService(GetAuthProviderRepo(client), GetUsuarioApp(), GetPontoDemandaApp());
            return service;
        }

        private static IAuthProviderRepository GetAuthProviderRepo(AppClient client)
        {
            var mockRepo = new Mock<IAuthProviderRepository>();
            if (client != null)
            {
                mockRepo.Setup(r => r.FindClient(It.IsAny<string>())).Returns(client);
            }
            return mockRepo.Object;
        }

        private static AppClient GetAppClient(AppTypes type, bool active = true)
        {
            return new AppClient { ApplicationType = type, Secret = "ZehL4zUy+3hMSBKWdfnv86aCsnFowOp0Syz1juAjN8U=", Active = active };
        }

        private static IUsuarioAplicacao GetUsuarioApp()
        {
            return new UsuarioAplicacao(GetUsuarioRepo(), new ContratoAplicacao(GetContratoRepo()), new Mock<INotificacaoAplicacao>().Object);
        }

        private static IRepositorioUsuario GetUsuarioRepo()
        {
            var usuario = GetUsuario();
            var mockRepo = new Mock<IRepositorioUsuario>();
            mockRepo.Setup(r => r.ObterPorLogin("usuario@invalido.com")).Throws(new LoginInvalidoException(LMResource.Usuario_LoginInvalido));
            mockRepo.Setup(r => r.ObterPorLogin(usuario.Login)).Returns(usuario);
            return mockRepo.Object;
        }

        private static IRepositorioContrato GetContratoRepo()
        {
            var mockRepo = new Mock<IRepositorioContrato>();
            mockRepo.Setup(r => r.ObterAtivo()).Returns(new Contrato {Ativo = true, Conteudo = "Lorem ipsum dolor sit amet"});
            return mockRepo.Object;
        }

        private static IPontoDemandaAplicacao GetPontoDemandaApp()
        {
            return new PontoDemandaAplicacao(GetPontoDemandaRepo(), new Mock<IUsuarioAplicacao>().Object);
        }

        private static IRepositorioPontoDemanda GetPontoDemandaRepo()
        {
            var mockRepo = new Mock<IRepositorioPontoDemanda>();
            mockRepo.Setup(r => r.Listar(It.IsAny<long>())).Returns(new List<PontoDemanda>{ GetPontoDemanda(1234), GetPontoDemanda(9876) });
            return mockRepo.Object;
        }

        private static Usuario GetUsuario()
        {
            return new Usuario
            {
                Id = 666,
                Login = "usuario@valido.com",
                Senha = "1000:kDmZMYqp3W/jYk09m6CHcSjtlaiV8eXk:LvI/I7PSjJl91dMN0dqLGiKnzILEjbXl",//"123789"
                Integrante = new Integrante { Nome = "Usuario", Email = "usuario@valido.com" }

            };
        }

        private static PontoDemanda GetPontoDemanda(long id)
        {
            return new PontoDemanda
            {
                Id = id
            };
        }
    }
}
