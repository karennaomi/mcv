﻿using LM.Core.Domain;
using LM.WebApi.DTO;
using Moq;
using NUnit.Framework;
using System.Net;

namespace LM.WebApi.App.Tests
{
    [TestFixture]
    public class PedidosControllerTests : BaseAuthenticatedTests
    {
        protected override string Uri
        {
            get { return "/api/pedidos"; }
        }

        [Test]
        [Ignore("Depois de um pedido criado não pode criar outro com mesmo produto pq a validação pega")]
        public void CriaUmPedido()
        {
            var response = PostAsync(GetPedidoItemDTO());
            Assert.AreEqual(HttpStatusCode.OK, response.Result.StatusCode);
        }

        private static ItemDTO GetPedidoItemDTO()
        {
            var itemMock = new Mock<IItem>();
            itemMock.Setup(i => i.ObterQuantidadeParaCompra()).Returns(10);
            return new ItemDTO(itemMock.Object, 0, 0, "")
            {
                Tipo = ItemTipoDTO.Pedido,
                Produto = new ProdutoDTO { Id = 113, Categoria = new CategoriaDTO { Id = 1 } },
                QuantidadeSugestaoCompra = 5
            };
        }
    }

    

}
