﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LM.WebApi.DTO;
using NUnit.Framework;

namespace LM.WebApi.App.Tests
{
    [TestFixture]
    public class DTOExtensionsTests
    {
        [Test]
        public void ListaDeCompraItensRespondeParaAgruparProdutosIguais()
        {
            var sugestao = new List<CompraItemDTO>();
            Assert.IsInstanceOf<IEnumerable<CompraItemDTO>>(sugestao.AgruparProdutosIguais());
        }

        [Test]
        public void ListaComDoisProdutosIguaisDepoisDeFiltradaDeveTerApenasUmItem()
        {
            var sugestao = new List<CompraItemDTO>
            {
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 1, Tipo = ItemTipoDTO.Lista, Produto = new ProdutoDTO {Id = 1}}
                },
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 2, Tipo = ItemTipoDTO.Pedido, Produto = new ProdutoDTO {Id = 1}}
                }
            };
            var agrupados = sugestao.AgruparProdutosIguais();
            Assert.AreEqual(1, agrupados.Count());
            Assert.AreEqual(1, agrupados.First().ItensComProdutosSemelhantes.Count());
        }

        [Test]
        public void ListaComVariosProdutosDeveAgruparCorretamente()
        {
            var sugestao = new List<CompraItemDTO>
            {
                //Pedido e Despensa
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 1, Tipo = ItemTipoDTO.Lista, Produto = new ProdutoDTO {Id = 1}}
                },
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 20, Tipo = ItemTipoDTO.Pedido, Produto = new ProdutoDTO {Id = 1}}
                }
                ,
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 21, Tipo = ItemTipoDTO.Pedido, Produto = new ProdutoDTO {Id = 1}}
                },

                //Varios Pedidos do mesmo produto
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 22, Tipo = ItemTipoDTO.Pedido, Produto = new ProdutoDTO {Id = 2}}
                },
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 23, Tipo = ItemTipoDTO.Pedido, Produto = new ProdutoDTO {Id = 2}}
                },
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 24, Tipo = ItemTipoDTO.Pedido, Produto = new ProdutoDTO {Id = 2}}
                },
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 25, Tipo = ItemTipoDTO.Pedido, Produto = new ProdutoDTO {Id = 2}}
                },
                
                //Somente um da despensa
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 26, Tipo = ItemTipoDTO.Lista, Produto = new ProdutoDTO {Id = 3}}
                },

                //Somente um pedido
                new CompraItemDTO
                {
                    Item = new ItemDTO {Id = 2, Tipo = ItemTipoDTO.Pedido, Produto = new ProdutoDTO {Id = 4}}
                }
            };
            var agrupados = sugestao.AgruparProdutosIguais().ToList();
            Assert.AreEqual(4, agrupados.Count());
            Assert.AreEqual(2, agrupados.Single(i => i.Item.Id == 1).ItensComProdutosSemelhantes.Count());
            Assert.AreEqual(3, agrupados.Single(i => i.Item.Id == 22).ItensComProdutosSemelhantes.Count());
            Assert.AreEqual(0, agrupados.Single(i => i.Item.Id == 26).ItensComProdutosSemelhantes.Count());
            Assert.AreEqual(0, agrupados.Single(i => i.Item.Id == 2).ItensComProdutosSemelhantes.Count());
        }
    }
}
