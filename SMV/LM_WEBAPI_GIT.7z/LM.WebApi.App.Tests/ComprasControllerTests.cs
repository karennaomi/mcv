﻿using LM.Core.Domain;
using LM.WebApi.DTO;
using NUnit.Framework;
using System.Collections.Generic;
using System.Net;
using System.Transactions;

namespace LM.WebApi.App.Tests
{
    [TestFixture]
    public class ComprasControllerTests : BaseAuthenticatedTests
    {
        protected override string Uri
        {
            get { return "/api/compras"; }
        }

        [Test]
        [Ignore("Precisa acertar os itens da compra com os itens do usuario sendo testado")]
        public void CriaUmaCompra()
        {
            using (new TransactionScope())
            {
                var response = PostAsync(GetCompraDTO());
                Assert.AreEqual(HttpStatusCode.Created, response.Result.StatusCode);
            }
        }

        private static CompraDTO GetCompraDTO()
        {
            return new CompraDTO
            {
                LojaId = 5,
                Itens = new List<CompraItemDTO>
                {
                    new CompraItemDTO{ Item = new ItemDTO{ Id = 3119, Produto = new ProdutoDTO{ Id = 27626}, Tipo = ItemTipoDTO.Lista}, Quantidade = 5, Valor = 5.50M, Status = StatusCompra.Comprado },
                    new CompraItemDTO{ Item = new ItemDTO{ Id = 74, Produto = new ProdutoDTO{ Id = 23249}, Tipo = ItemTipoDTO.Pedido}, Quantidade = 2, Valor = 1.25M, Status = StatusCompra.AgoraNao },
                    new CompraItemDTO{ Item = new ItemDTO{ Id = 75, Produto = new ProdutoDTO{ Id = 418}, Tipo = ItemTipoDTO.Pedido}, Quantidade = 1, Valor = 2.25M, Status = StatusCompra.Comprado },
                    new CompraItemDTO{ Item = new ItemDTO{ Id = 3120, Produto = new ProdutoDTO{ Id = 27627}, Tipo = ItemTipoDTO.Lista}, Quantidade = 1, Valor = 3.00M, Status = StatusCompra.ItemSubstituido, ItemSubstituto  = new CompraItemDTO
                    {
                        Item = new ItemDTO{ Id = 3121, Produto = new ProdutoDTO{ Id = 27628 }, Tipo = ItemTipoDTO.Lista}, Quantidade = 1, Valor = 2, Status = StatusCompra.Comprado
                    }},
                    new CompraItemDTO{ Item = new ItemDTO{Produto = new ProdutoDTO{ Nome = "Produto do teste", Ean = "1s2s5rvbr"}, Tipo = ItemTipoDTO.Lista}, Quantidade = 5, Valor = 5.50M, Status = StatusCompra.Comprado }
                }
            };
        }
    }

    

}
