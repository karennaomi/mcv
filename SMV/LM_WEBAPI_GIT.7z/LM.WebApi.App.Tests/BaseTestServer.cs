﻿using System.Net.Http;
using System.Net.Http.Formatting;
using System.Threading.Tasks;
using Microsoft.Owin.Testing;
using NUnit.Framework;

namespace LM.WebApi.App.Tests
{
    public abstract class BaseTestServer
    {
        protected TestServer Server { get; set; }

        [TestFixtureSetUp]
        public void Setup()
        {
            Server = TestServer.Create<TestStartup>();
            PostSetup(Server);
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            if (Server != null) Server.Dispose();
        }

        protected abstract string Uri { get; }

        protected virtual async Task<HttpResponseMessage> GetAsync()
        {
            return await Server.CreateRequest(Uri).GetAsync();
        }

        protected virtual async Task<HttpResponseMessage> PostAsync<TModel>(TModel model)
        {
            return await Server.CreateRequest(Uri)
            .And(request => request.Content = new ObjectContent(typeof(TModel), model, new JsonMediaTypeFormatter()))
            .PostAsync();
        }

        protected virtual async Task<HttpResponseMessage> DeleteAsync(object id)
        {
            return await Server.CreateRequest(Uri + "/" + id)
            .SendAsync("DELETE");
        }

        protected virtual void PostSetup(TestServer server)
        {
        }
    }
}
