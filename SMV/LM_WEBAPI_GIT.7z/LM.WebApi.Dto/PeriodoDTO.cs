﻿using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    public class PeriodoDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public PeriodoDTO() { }
        public PeriodoDTO(Periodo periodo)
        {
            Id = periodo.Id;
            Nome = periodo.Nome;
        }

        public Periodo ObterPeriodo()
        {
            return new Periodo { Id = Id, Nome = Nome };
        }
    }
}
