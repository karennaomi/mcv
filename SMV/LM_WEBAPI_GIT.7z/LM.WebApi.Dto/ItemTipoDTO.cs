﻿using System;

namespace LM.WebApi.DTO
{
    [Serializable]
    public enum ItemTipoDTO
    {
        Lista, Pedido
    }
}
