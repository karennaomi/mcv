﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using LM.Core.Domain;
using System;

namespace LM.WebApi.DTO
{
    [Serializable]
    public class IntegranteDTO : IValidatableObject
    {
        private readonly Integrante _integrante;

        public IntegranteDTO()
        {
            _integrante = new Integrante { GruposDeIntegrantes = new Collection<GrupoDeIntegrantes>() };
        }
        public IntegranteDTO(Integrante integrante)
        {
            _integrante = integrante;
        }

        public long Id
        {
            get { return _integrante.Id; }
            set { _integrante.Id = value; }
        }

        [LMRequired]
        [LMMaxLength(Constantes.Integrante.TamanhoMaximoNome)]
        public string Nome
        {
            get { return _integrante.Nome; }
            set { _integrante.Nome = value; }
        }

        public DateTime? DataNascimento
        {
            get { return _integrante.DataNascimento; }
            set { _integrante.DataNascimento = value == DateTime.MinValue ? null : value; }
        }

        public string Email
        {
            get { return _integrante.Email; }
            set { _integrante.Email = value; }
        }

        public string Telefone
        {
            get { return _integrante.Telefone; }
            set { _integrante.Telefone = value; }
        }

        public string Sexo
        {
            get { return _integrante.Sexo; }
            set { _integrante.Sexo = value; }
        }

        public string Tipo
        {
            get { return _integrante.Tipo.ToString(); }
            set { _integrante.Tipo = (TipoIntegrante)Enum.Parse(typeof(TipoIntegrante), value, true); }
        }

        public DateTime? DataConvite
        {
            get { return _integrante.DataConvite; }
            set { _integrante.DataConvite = value; }
        }

        public bool PodeSerConvidado
        {
            get { return _integrante.PodeSerConvidado(); }
        }

        public bool EhUsuarioDoSistema
        {
            get { return _integrante.EhUsuarioDoSistema(); }
        }

        public long UsuarioId
        {
            get { return _integrante.EhUsuarioDoSistema() ? _integrante.Usuario.Id : 0; }
        }

        public int? AnimalId
        {
            get { return _integrante.AnimalId; }
            set { _integrante.AnimalId = value; }
        }

        public Integrante ObterIntegrante()
        {
            return _integrante;
        }

        IEnumerable<ValidationResult> IValidatableObject.Validate(ValidationContext validationContext)
        {
            return _integrante.Validate(validationContext);
        }
    }
}
