﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LM.WebApi.DTO
{
    public static class DTOExtensions
    {
        public static IEnumerable<CompraItemDTO> BlasterOrder(this IEnumerable<CompraItemDTO> itens)
        {
            return itens.OrderBy(c => c.Item.Produto.Categoria.Secao.Nome).ThenBy(c => c.Item.Produto.Nome).ThenByDescending(c => c.Item.EhEssencial).ThenByDescending(c => c.Item.Tipo);
        }

        public static decimal OneDecimalPlace(this decimal value)
        {
            return Math.Truncate(value*10)/10;
        }

        public static decimal Round(this decimal value)
        {
            return Math.Round(value);
        }

        public static IEnumerable<CompraItemDTO> AgruparProdutosIguais(this IEnumerable<CompraItemDTO> compraItens)
        {
            var itensAgrupados = compraItens.GroupBy(c => c.Item.Produto.Id);
            return itensAgrupados.Select(CriarAgrupamento);
        }

        private static CompraItemDTO CriarAgrupamento(IGrouping<int, CompraItemDTO> grouping)
        {
            var primeiroItem = grouping.First();
            var outrosItems = grouping.Where(i => i.Item.Id != primeiroItem.Item.Id);
            primeiroItem.ItensComProdutosSemelhantes = outrosItems;
            return primeiroItem;
        }
    }
}
