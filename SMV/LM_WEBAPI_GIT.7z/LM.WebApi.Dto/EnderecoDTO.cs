﻿using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    public class EnderecoDTO
    {
        public EnderecoDTO() { }

        public EnderecoDTO(Endereco endereco)
        {
            if(endereco == null) return;
            Logradouro = endereco.Logradouro;
            Numero = endereco.Numero;
            Complemento = endereco.Complemento;
            Cep = endereco.Cep;
            Bairro = endereco.Bairro;
            Latitude = endereco.Latitude;
            Longitude = endereco.Longitude;
            Cidade = endereco.Cidade;
            Estado = endereco.Uf;
            EnderecoCompleto = endereco.ToString();
        }
        
        [LMRequired]
        public string Logradouro { get; set; }
        public int? Numero { get; set; }
        public string Complemento { get; set; }
        public string Cep { get; set; }
        public string Bairro { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public string EnderecoCompleto { get; private set; }

        public Endereco ObterEndereco()
        {
            return new Endereco
            {
                Logradouro = Logradouro,
                Numero = Numero,
                Complemento = Complemento,
                Cep = Cep,
                Bairro = Bairro,
                Latitude = Latitude,
                Longitude = Longitude,
                Cidade = Cidade, 
                Uf = Estado
            };
        }
    }
}
