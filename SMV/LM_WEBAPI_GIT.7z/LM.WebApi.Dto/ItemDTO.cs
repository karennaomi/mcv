﻿using LM.Core.Domain;
using System;

namespace LM.WebApi.DTO
{
    [Serializable]
    public class ItemDTO
    {
        public long Id { get; set; }
        public DateTime? DataInclusao { get; set; }
        public DateTime? DataAlteracao { get; set; }
        public ProdutoDTO Produto { get; set; }
        public ItemTipoDTO Tipo { get; set; }
        
        private decimal? _consumo;
        public decimal QuantidadeConsumo
        {
            get { return _consumo.HasValue ? _consumo.Value : 0; }
            set { _consumo = value; }
        }

        private decimal _sugestaoCompra;
        public decimal QuantidadeSugestaoCompra
        {
            get { return _sugestaoCompra.Round(); }
            set { _sugestaoCompra = value; }
        }

        private decimal? _estoque;
        public decimal QuantidadeEstoque
        {
            get { return _estoque.HasValue ? _estoque.Value.OneDecimalPlace() : 0; }
            set { _estoque = value; }
        }

        private readonly decimal? _estoqueEstimado;
        public decimal? QuantidadeEstoqueEstimado
        {
            get
            {
                return _estoqueEstimado.HasValue ? (decimal?)_estoqueEstimado.Value.OneDecimalPlace() : null;
            }
        }

        public int PeriodoId { get; set; }
        public bool EhEssencial { get; set; }
        public int StatusPedidoId { get; set; }
        public StatusPedido? StatusPedido { get; set; }
        public IntegranteDTO Integrante { get; set; }

        public ItemDTO() { }
        public ItemDTO(PedidoItem pedidoItem, ListaItem listaItem, int interfaceId, int resolucaoId, string imagemHost) : this(pedidoItem, interfaceId, resolucaoId, imagemHost)
        {
            _estoque = listaItem != null ? listaItem.QuantidadeEstoque : 0;
        }

        public ItemDTO(IItem item, int interfaceId, int resolucaoId, string imagemHost)
        {
            Id = item.Id;
            DataInclusao = item.DataInclusao;
            DataAlteracao = item.DataAlteracao;
            _sugestaoCompra = item.ObterQuantidadeParaCompra();

            if (item is ListaItem)
            {
                var listaItem = item as ListaItem;
                Tipo = ItemTipoDTO.Lista;
                _consumo = listaItem.QuantidadeConsumo;
                _estoque = listaItem.QuantidadeEstoque;
                _estoqueEstimado = listaItem.QuantidadeDoEstoqueEstimado;
                PeriodoId = listaItem.Periodo != null ? listaItem.Periodo.Id : 0;
                EhEssencial = listaItem.EhEssencial;
                if (listaItem.AtualizadoPor != null)
                {
                    Integrante = new IntegranteDTO(listaItem.AtualizadoPor.Integrante);
                }
            }
            else if (item is PedidoItem)
            {
                var pedidoItem = item as PedidoItem;
                Tipo = ItemTipoDTO.Pedido;
                StatusPedidoId = (int)pedidoItem.Status;
                StatusPedido = pedidoItem.Status;
                if (pedidoItem.Integrante != null)
                { 
                    Integrante = new IntegranteDTO(pedidoItem.Integrante);
                }
            }

            Produto = new ProdutoDTO(item.Produto, interfaceId, resolucaoId, imagemHost);
        }

        public ListaItem ObterListaItem(long usuarioId, long pontoDemandaId, string origem)
        {
            return new ListaItem
            {
                Id = Id,
                QuantidadeConsumo = QuantidadeConsumo,
                QuantidadeEstoque = QuantidadeEstoque,
                Periodo = new Periodo { Id = PeriodoId },
                Produto = Produto.ObterProduto(origem),
                EhEssencial = EhEssencial
            };
        }

        public PedidoItem ObterPedidoItem(long usuarioId, long pontoDemandaId, string origem)
        {
            return new PedidoItem
            {
                Id = Id,
                QuantidadeSugestaoCompra = QuantidadeSugestaoCompra,
                Produto = Produto.ObterProduto(origem),
                PontoDemanda = new PontoDemanda { Id = pontoDemandaId },
                Integrante = new Integrante { Usuario = new Usuario{ Id = usuarioId}}
            };
        }
    }
}
