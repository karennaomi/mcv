﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    public class CompraDTO : IValidatableObject
    {
        public CompraDTO()
        {
            Itens = new List<CompraItemDTO>();
        }

        public CompraDTO(Compra compra, int interfaceId, int resolucaoId, string imagemHost)
        {
            Id = compra.Id;
            LojaId = compra.LojaId;
            DataInicioCompra = compra.DataInicioCompra;
            DataCapturaPrimeiroItemCompra = compra.DataCapturaPrimeiroItemCompra;
            DataFimCompra = compra.DataFimCompra;
            Itens = new List<CompraItemDTO>();
            foreach (var compraItem in compra.Itens)
            {
                Itens.Add(new CompraItemDTO(compraItem, interfaceId, resolucaoId, imagemHost));
            }
        }

        public long Id { get; set; }
        [LMRequired(ErrorMessage = "Por favor informe a loja.")]
        public int LojaId { get; set; }
        public DateTime? DataInicioCompra { get; set; }
        public DateTime? DataCapturaPrimeiroItemCompra { get; set; }
        public DateTime? DataFimCompra { get; set; }
        public IList<CompraItemDTO> Itens { get; set; }

        public Compra ObterCompra(Usuario usuario, long pontoPontoDemandaId, string origem)
        {
            var compra = new Compra
            {
                Integrante = new Integrante { Id = usuario.Integrante.Id, Usuario = new Usuario { Id = usuario.Id }},
                PontoDemanda = new PontoDemanda { Id = pontoPontoDemandaId },
                LojaId = LojaId,
                DataInicioCompra = DataInicioCompra,
                DataCapturaPrimeiroItemCompra = DataCapturaPrimeiroItemCompra,
                DataFimCompra = DateTime.Now
            };

            if (compra.Itens == null) compra.Itens = new Collection<CompraItem>();
            foreach (var itemDTO in Itens)
            {
                var item = itemDTO.ObterCompraItem(usuario.Id, pontoPontoDemandaId, origem);
                if (itemDTO.ItemSubstituto == null)
                {
                    compra.Itens.Add(item);
                }
                else
                {
                    compra.AdicionarItemSubstituto(item, itemDTO.ItemSubstituto.ObterCompraItem(usuario.Id, pontoPontoDemandaId, origem), itemDTO.ItemSubstituto.MotivoSubstituicao.ObterMotivoSubstituicao());
                }
            }
            return compra;
        }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (LojaId <= 0) yield return new ValidationResult("Por favor informe a loja.", new[] { "LojaId" });
        }
    }
}
