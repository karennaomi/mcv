﻿
namespace LM.WebApi.DTO
{
    public class DeviceInfoDTO
    {
        public string DeviceId { get; set; }
        public string DeviceType { get; set; }
    }
}
