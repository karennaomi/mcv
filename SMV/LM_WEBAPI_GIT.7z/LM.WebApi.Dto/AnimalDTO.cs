﻿using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    public class AnimalDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public AnimalDTO() { }
        public AnimalDTO(Animal animal)
        {
            Id = animal.Id;
            Nome = animal.Nome;
        }

        public Animal ObterAnimal()
        {
            return new Animal{ Id = Id, Nome = Nome};
        }
    }
}
