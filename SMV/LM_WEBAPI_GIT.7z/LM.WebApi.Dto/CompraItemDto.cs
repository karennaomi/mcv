﻿using System;
using System.Collections.Generic;
using System.Linq;
using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    [Serializable]
    public class CompraItemDTO
    {
        public CompraItemDTO() { }

        public CompraItemDTO(IItem item, int interfaceId, int resolucaoId, string imagemHost)
        {
            Item = new ItemDTO(item, interfaceId, resolucaoId, imagemHost);
            Status = StatusCompra.ItemAComprar;
            Quantidade = item.ObterQuantidadeParaCompra().Round();
        }

        public CompraItemDTO(CompraItem compraItem, int interfaceId, int resolucaoId, string imagemHost)
        {
            Id = compraItem.Id;
            Status = compraItem.Status;
            Quantidade = compraItem.Quantidade.HasValue ? compraItem.Quantidade.Value : 0;
            Valor = compraItem.Valor.HasValue ? compraItem.Valor.Value : 0;
            DataCompra = compraItem.DataCompra;
            CompradoPor = compraItem.Compra.Integrante.Nome;
            if (compraItem is ListaCompraItem)
            {
                var listaCompraItem = compraItem as ListaCompraItem;
                Item = new ItemDTO(listaCompraItem.Item, interfaceId, resolucaoId, imagemHost);
            }
            else if (compraItem is PedidoCompraItem)
            {
                var pedidoCompraItem = compraItem as PedidoCompraItem;
                Item = new ItemDTO(pedidoCompraItem.Item, interfaceId, resolucaoId, imagemHost);
            }    
        }

        public long Id { get; set; }
        public StatusCompra Status { get; set; }
        public decimal Quantidade { get; set; }
        public decimal Valor { get; set; }
        public DateTime? DataCompra { get; set; }
        public MotivoSubstituicaoDTO MotivoSubstituicao { get; set; }
        public string CompradoPor { get; set; }
        public CompraItemDTO ItemSubstituto { get; set; }
        public ItemDTO Item { get; set; }
        public IEnumerable<CompraItemDTO> ItensComProdutosSemelhantes { get; set; }
        public decimal QuantidadeTotal
        {
            get
            {
                var quantidadeSemelhantes = ItensComProdutosSemelhantes == null ? 0 : ItensComProdutosSemelhantes.Sum(s => s.Item.QuantidadeSugestaoCompra);
                return Item.QuantidadeSugestaoCompra + quantidadeSemelhantes;
            }
        }
        public decimal QuantidadeTotalDePedidos
        {
            get
            {
                var quantidadePrincipal = Item.Tipo == ItemTipoDTO.Pedido ? Item.QuantidadeSugestaoCompra : 0;
                var quantidadeSemelhantes = ItensComProdutosSemelhantes == null ? 0 : ItensComProdutosSemelhantes.Where(s => s.Item.Tipo == ItemTipoDTO.Pedido).Sum(s => s.Item.QuantidadeSugestaoCompra);
                return quantidadePrincipal+ quantidadeSemelhantes;
            }
        }

        public CompraItem ObterCompraItem(long usuarioId, long pontoDemandaId, string origem)
        {
            CompraItem compraItem;
            switch (Item.Tipo)
            {
                case ItemTipoDTO.Lista:
                    compraItem = new ListaCompraItem { Item = Item.ObterListaItem(usuarioId, pontoDemandaId, origem), ProdutoId = Item.Produto.Id > 0 ? (int?)Item.Produto.Id : null };
                    break;
                case ItemTipoDTO.Pedido:
                    compraItem = new PedidoCompraItem { Item = Item.ObterPedidoItem(usuarioId, pontoDemandaId, origem), ProdutoId = Item.Produto.Id > 0 ? (int?)Item.Produto.Id : null };
                    break;
                default: throw new ApplicationException("Tipo de item inválido.");

            }
            compraItem.Quantidade = Quantidade;
            compraItem.Valor = Valor;
            compraItem.DataCompra = DataCompra;
            compraItem.Status = Status;
            return compraItem;
        }
    }
}
