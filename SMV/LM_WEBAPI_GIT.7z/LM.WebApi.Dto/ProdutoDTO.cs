﻿using LM.Core.Domain;
using System;
using System.Linq;

namespace LM.WebApi.DTO
{
    [Serializable]
    public class ProdutoDTO
    {
        public ProdutoDTO() { }
        public ProdutoDTO(Produto produto, int interfaceId, int resolucaoId, string imagemHost)
        {
            if (produto == null) return;
            Id = produto.Id;
            Nome = produto.Nome();
            Imagem = string.Format("{0}{1}", imagemHost, produto.ImagemPrincipal().Path);
            Ean = produto.Ean;
            PrecoMedio = produto.PrecoMedio();
            Categoria = new CategoriaDTO(produto.Categorias.First(), interfaceId, resolucaoId, imagemHost);
        }

        public int Id { get; set; }
        [LMRequired]
        public string Nome { get; set; }
        public string Imagem { get; set; }
        [LMMaxLength(Constantes.Produto.TamanhoMaximoEan)]
        public string Ean { get; set; }
        public decimal PrecoMedio { get; private set; }
        public CategoriaDTO Categoria { get; set; }

        public Produto ObterProduto(string origem)
        {
            return new Produto(Nome, Ean, origem, Categoria.Id == 0 ? 3 : Categoria.Id, Imagem) // 3 Categoria Diversos
            {
                Id = Id
            };
        }
    }
}
