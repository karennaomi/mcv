﻿using System.ComponentModel;
using LM.Core.Domain;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace LM.WebApi.DTO
{
    public class UsuarioDTO : IValidatableObject
    {
        private readonly Usuario _usuario;
        public UsuarioDTO()
        {
            _usuario = new Usuario { Integrante = new Integrante{ GruposDeIntegrantes = new Collection<GrupoDeIntegrantes>() }, StatusUsuarioPontoDemanda = new Collection<StatusUsuarioPontoDemanda>{new StatusUsuarioPontoDemanda()}};
        }
        public UsuarioDTO(Usuario usuario)
        {
            _usuario = usuario;
            _usuario.Senha = null;
        }

        public long Id
        {
            get { return _usuario.Id; }
            set { _usuario.Id = value; }
        }

        [LMRequired]
        [LMMaxLength(Constantes.Integrante.TamanhoMaximoNome)]
        public string Nome
        {
            get { return _usuario.Integrante.Nome; }
            set { _usuario.Integrante.Nome = value; }
        }

        [LMRequired]
        [LMMaxLength(Constantes.Integrante.TamanhoMaximoEmail)]
        [LMEmail]
        [DisplayName("E-mail")]
        public string Email
        {
            get { return _usuario.Integrante.Email; }
            set { _usuario.Integrante.Email = value; }
        }

        [LMRequired]
        [LMMinLength(Constantes.Usuario.TamanhoMinimoSenha)]
        public string Senha
        {
            get { return _usuario.Senha; }
            set { _usuario.Senha = value; }
        }

        [LMRequired]
        [DisplayName("Data de nascimento")]
        public DateTime? DataNascimento
        {
            get { return _usuario.Integrante.DataNascimento; }
            set { _usuario.Integrante.DataNascimento = value; }
        }

        [LMRequired]
        public string Sexo
        {
            get { return _usuario.Integrante.Sexo; }
            set { _usuario.Integrante.Sexo = value; }
        }

        public StatusCadastro StatusAtual
        {
            get { return _usuario.StatusUsuarioPontoDemanda.OrderByDescending(s => s.Id).First().StatusCadastro; }
        }

        public int StatusAtualId
        {
            get { return (int)_usuario.StatusUsuarioPontoDemanda.OrderByDescending(s => s.Id).First().StatusCadastro; }
        }

        public Usuario ObterUsuario()
        {
            return _usuario;
        }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            return _usuario.Validate(validationContext);
        }
    }
}
