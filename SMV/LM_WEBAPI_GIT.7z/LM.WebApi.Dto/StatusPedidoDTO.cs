﻿using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    public class StatusPedidoDTO
    {
        public StatusPedidoDTO(StatusPedido status)
        {
            Id = (int) status;
            Nome = status.ToString();
            switch (status)
            {
                case StatusPedido.Pendente:
                    Cor = "#878786"; break;
                case StatusPedido.Rejeitado:
                    Cor = "#F8B123"; break;
                case StatusPedido.Comprado:
                    Cor = "#8DBF4B"; break;
                case StatusPedido.Substituido:
                    Cor = "#006B2D"; break;
                default: Cor = "#878786"; break;
            }
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Cor { get; set; }

        
    }
}
