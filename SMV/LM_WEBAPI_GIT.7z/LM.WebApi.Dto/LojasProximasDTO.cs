﻿using LM.Core.Domain;
using System.Collections.Generic;
using System.Linq;

namespace LM.WebApi.DTO
{
    public class LojasProximasDTO
    {
        public string NextPageToken { get; set; }
        public EnderecoDTO EnderecoLocal { get; set; }
        public IEnumerable<LojaDTO> Lojas { get; set; }

        public LojasProximasDTO(BuscaLojaResult result)
        {
            NextPageToken = result.NextPageToken;
            EnderecoLocal = new EnderecoDTO(result.EnderecoLocal);
            Lojas = result.Lojas.Select(l => new LojaDTO(l));
        }
    }
}
