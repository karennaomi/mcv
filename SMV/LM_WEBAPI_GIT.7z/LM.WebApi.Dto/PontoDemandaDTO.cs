﻿using System.ComponentModel;
using LM.Core.Domain;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace LM.WebApi.DTO
{
    public class PontoDemandaDTO
    {
        private readonly PontoDemanda _pontoDemanda;
        public PontoDemandaDTO()
        {
            _pontoDemanda = new PontoDemanda {Tipo = TipoPontoDemanda.Casa, };
        }

        public PontoDemandaDTO(PontoDemanda pontoDemanda)
        {
            _pontoDemanda = pontoDemanda;
            Endereco = new EnderecoDTO(_pontoDemanda.Endereco);
            if (pontoDemanda.LojasFavoritas == null) return;
            LojasFavoritas = new Collection<LojaDTO>();
            foreach (var lojaFavorita in pontoDemanda.LojasFavoritas)
            {
                LojasFavoritas.Add(new LojaDTO(lojaFavorita));
            }
        }

        public long Id
        {
            get { return _pontoDemanda.Id; }
            set { _pontoDemanda.Id = value; }
        }

        [Required(ErrorMessage = "O campo nome é de preenchimento obrigatório!", AllowEmptyStrings = false)]
        public string Nome
        {
            get { return _pontoDemanda.Nome; }
            set { _pontoDemanda.Nome = value; }
        }

        public short? FrequenciaDeCompra
        {
            get { return _pontoDemanda.QuantidadeDiasAlertaReposicao; }
            set { _pontoDemanda.QuantidadeDiasAlertaReposicao = value; }
        }

        public TipoPontoDemanda? Tipo
        {
            get { return _pontoDemanda.Tipo; }
            set { _pontoDemanda.Tipo = value; }
        }

        [LMRequired]
        [DisplayName("Endereço")]
        public EnderecoDTO Endereco { get; set; }

        public ICollection<LojaDTO> LojasFavoritas { get; set; }

        public PontoDemanda ObterPontoDemanda()
        {
            _pontoDemanda.Endereco = Endereco.ObterEndereco();
            if (LojasFavoritas == null || !LojasFavoritas.Any()) return _pontoDemanda;
            _pontoDemanda.LojasFavoritas = new Collection<Loja>();
            foreach (var lojaDTO in LojasFavoritas)
            {
                _pontoDemanda.LojasFavoritas.Add(lojaDTO.ObterLoja());
            }
            return _pontoDemanda;
        }
    }
}
