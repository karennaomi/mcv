﻿using System;
using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    public class CompraAtivaDTO
    {
        public CompraAtivaDTO(CompraAtiva compraAtiva)
        {
            PontoDemandaId = compraAtiva.PontoDemanda.Id;
            UsuarioId = compraAtiva.Usuario.Id;
            InicioCompra = compraAtiva.InicioCompra;
            FimCompra = compraAtiva.FimCompra;
        }
        public long PontoDemandaId { get; set; }
        public long UsuarioId { get; set; }
        public DateTime InicioCompra { get; set; }
        public DateTime? FimCompra { get; set; }
    }
}
