﻿using System.Globalization;
using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    public class LojaDTO
    {
        public LojaDTO() { }

        public LojaDTO(Loja loja)
        {
            Id = loja.Id;
            Nome = loja.Nome;
            LocalizadorId = loja.LocalizadorId;
            LocalizadorOrigem = loja.LocalizadorOrigem;
            Endereco = loja.Info.Endereco.ToString();
            _enderecoLat = loja.Info.Endereco.Latitude;
            _enderecoLng = loja.Info.Endereco.Longitude;
            Telefone = loja.Info.Telefone;
            Proximidade = loja.Proximidade;
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string LocalizadorId { get; set; }
        public string LocalizadorOrigem { get; set; }
        public string Telefone { get; set; }
        public string Proximidade { get; set; }
        public string Endereco { get; set; }
        
        private decimal _enderecoLat;
        public string EnderecoLatitude
        {
            get { return _enderecoLat.ToString(new CultureInfo("en-US")); }
            set { _enderecoLat = value == null ? 0 : decimal.Parse(value, new CultureInfo("en-US")); }
        }

        private decimal _enderecoLng;
        public string EnderecoLongitude
        {
            get { return _enderecoLng.ToString(new CultureInfo("en-US")); }
            set { _enderecoLng = value == null ? 0 : decimal.Parse(value, new CultureInfo("en-US")); }
        }

        public Loja ObterLoja()
        {
            return new Loja
            {
                Nome = Nome,
                LocalizadorId = LocalizadorId,
                LocalizadorOrigem = LocalizadorOrigem,
                Proximidade = Proximidade,
                Info = new LojaInfo
                {
                    RazaoSocial = Nome,
                    Telefone = Telefone,
                    Endereco = new Endereco
                    {
                        Alias = Nome,
                        Logradouro = Endereco,
                        Latitude = _enderecoLat,
                        Longitude = _enderecoLng
                    }
                }
            };
        }
    }
}
