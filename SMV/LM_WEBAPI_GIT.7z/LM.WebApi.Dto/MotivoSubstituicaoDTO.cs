﻿using System;
using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    [Serializable]
    public class MotivoSubstituicaoDTO
    {
        public MotivoSubstituicaoDTO() { }
        public MotivoSubstituicaoDTO(MotivoSubstituicao motivoSubstituicao)
        {
            Id = motivoSubstituicao.Id;
            Motivo = motivoSubstituicao.Motivo;
        }

        public int Id { get; set; }
        public string Motivo { get; set; }

        public MotivoSubstituicao ObterMotivoSubstituicao()
        {
            return new MotivoSubstituicao { Id = Id };
        }
    }
}
