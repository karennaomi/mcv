﻿using System;
using LM.Core.Domain;

namespace LM.WebApi.DTO
{
    [Serializable]
    public class CategoriaDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Cor { get; set; }
        public string Imagem { get; set; }
        public CategoriaDTO Secao { get; set; }

        public CategoriaDTO() { }
        public CategoriaDTO(Categoria categoria, int interfaceId, int resolucaoId, string imagemHost)
        {
            Id = categoria.Id;
            Nome = categoria.Nome;
            Cor = categoria.Cor;
            Imagem = string.Format("{0}{1}", imagemHost, categoria.ImagemPrincipal(interfaceId, resolucaoId)); ;
            if (categoria.Id != categoria.CategoriaPai.Id)
            {
                Secao = new CategoriaDTO(categoria.CategoriaPai, interfaceId, resolucaoId, imagemHost);
            }
        }

        
    }
}
