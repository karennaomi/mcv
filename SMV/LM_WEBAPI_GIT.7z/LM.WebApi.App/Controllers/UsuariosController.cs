﻿using LM.Core.Application;
using LM.Core.Domain;
using LM.Core.Domain.CustomException;
using LM.WebApi.App.ExceptionHandling;
using LM.WebApi.App.Models;
using LM.WebApi.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;

namespace LM.WebApi.App.Controllers
{
    public class UsuariosController : BaseApiController
    {
        private readonly IUsuarioAplicacao _appUsuario;
        private readonly IRecuperarSenhaAplicacao _appRecuperarSenha;
        public UsuariosController(IUsuarioAplicacao appUsuario, IRecuperarSenhaAplicacao appRecuperarSenha)
        {
            _appUsuario = appUsuario;
            _appRecuperarSenha = appRecuperarSenha;
        }

        public UsuarioDTO Get()
        {
            return new UsuarioDTO(_appUsuario.Obter(ObterUsuarioId()));
        }

        public UsuarioDTO Get(string email)
        {
            return new UsuarioDTO(_appUsuario.Obter(email));
        }

        [ResponseType(typeof(UsuarioDTO))]
        public IHttpActionResult Post(UsuarioDTO usuarioDTO)
        {
            if (!ModelState.IsValid) throw new ValidationException(ModelState);
            try
            {
                var usuario = _appUsuario.Criar(usuarioDTO.ObterUsuario());
                return CreatedAtRoute("DefaultApi", null, new UsuarioDTO(usuario));
            }
            catch (IntegranteExistenteException ex)
            {
                ModelState.AddModelError(ex.Property, ex.Message);
                throw new ValidationException(ModelState);
            }
        }

        [ResponseType(typeof(UsuarioDTO))]
        public void Put(UsuarioDTO usuarioDTO)
        {
            ModelState["UsuarioDTO.Senha"].Errors.Clear();
            if (!ModelState.IsValid) throw new ValidationException(ModelState);
            var usuario = usuarioDTO.ObterUsuario();
            usuario.Id = ObterUsuarioId();
            _appUsuario.Atualizar(usuario);
        }

        [HttpPost]
        [Route("api/usuarios/atualizardeviceinfo")]
        public void AtualizarDeviceInfo(DeviceInfoDTO deviceinfoDTO)
        {
            _appUsuario.AtualizarDeviceInfo(ObterUsuarioId(), deviceinfoDTO.DeviceType, deviceinfoDTO.DeviceId);
        }

        [HttpPost]
        [Route("api/usuarios/atualizarstatuscadastro")]
        public void AtualizarStatusCadastro([FromBody]int statusValue)
        {
            var pontoDemandaId = ObterPontoDemandaId();
            var status = (StatusCadastro)statusValue;
            if (pontoDemandaId > 0)
            {
                _appUsuario.AtualizarStatusCadastro(ObterUsuarioId(), status, pontoDemandaId);
            }
            else
            {
                _appUsuario.AtualizarStatusCadastro(ObterUsuarioId(), status);
            }
        }

        [HttpPost]
        [Route("api/usuarios/recuperarsenha")]
        [ResponseType(typeof(RecuperarSenhaDTO))]
        public IHttpActionResult RecuperarSenha([FromBody]string email)
        {
            var recuperarSenha = _appRecuperarSenha.RecuperarSenha(email, AppHelper.UrlTrocarSenha, AppHelper.ImagemHost);
            return Ok(new RecuperarSenhaDTO(recuperarSenha));
        }

        [HttpGet]
        [Route("api/usuarios/statuscadastro")]
        public IDictionary<int, string> StatusCadastro()
        {
            return Enum.GetValues(typeof (StatusCadastro)).Cast<StatusCadastro>().ToDictionary(s => (int)s, s => s.ToString());
        }
    }
}
