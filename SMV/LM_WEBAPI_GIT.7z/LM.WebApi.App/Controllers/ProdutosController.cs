﻿using LM.Core.Application;
using LM.WebApi.App.ExceptionHandling;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;

namespace LM.WebApi.App.Controllers
{
    public class ProdutosController : BaseApiController
    {
        private readonly IProdutoAplicacao _appProduto;
        public ProdutosController(IProdutoAplicacao appProduto)
        {
            _appProduto = appProduto;
        }

        public IEnumerable<ProdutoDTO> Get(int categoriaId, int resolucaoId = ResolucaoIdPadrao)
        {
            return _appProduto.ListarPorCategoria(ObterPontoDemandaId(), categoriaId).Select(p => new ProdutoDTO(p, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost));
        }

        [ResponseType(typeof(ProdutoDTO))]
        public IHttpActionResult Post(ProdutoDTO produtoDTO, int resolucaoId = ResolucaoIdPadrao)
        {
            if (!ModelState.IsValid) throw new ValidationException(ModelState);
            var produto = _appProduto.Criar(produtoDTO.ObterProduto(ObterClientApp()), ObterUsuarioId());
            return Ok(new ProdutoDTO(produto, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost));
        }

        [HttpGet]
        [Route("api/produtos/buscar")]
        public IEnumerable<ProdutoDTO> Buscar(string termo, int resolucaoId = ResolucaoIdPadrao)
        {
            return _appProduto.Buscar(ObterPontoDemandaId(), termo).Select(p => new ProdutoDTO(p, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost));
        }
    }
}
