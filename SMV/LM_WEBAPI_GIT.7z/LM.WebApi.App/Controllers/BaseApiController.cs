﻿using LM.WebApi.App.Models;
using System;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Web.Http;

namespace LM.WebApi.App.Controllers
{
    [Authorize]
    public class BaseApiController : ApiController
    {
        //Esses ids são os que estão na tabela TB_Imagem_Resolucao
        protected const int ResolucaoIdPadrao = 3; 

        protected long ObterUsuarioId()
        {
            return ObterLongId(LMClaimTypes.UsuarioId);
        }

        protected long ObterPontoDemandaId()
        {
            return ObterLongId(LMClaimTypes.PontoDemandaId);
        }

        protected string ObterClientApp()
        {
            return GetClaimValue(LMClaimTypes.InterfaceId);
        }

        protected int ObterInterfaceId()
        {
            switch (ObterClientApp()) //Esses ids são os que estão na tabela TB_Imagem_Interface
            {
                case "web_app":
                    return 2;
                case "ios_app":
                    return 4;
                case "android_app":
                    return 3;
                default:
                    return 5;
            }
        }

        private long ObterLongId(string claimType)
        {
            var claimValue = GetClaimValue(claimType);
            return long.Parse(claimValue);
        }

        private string GetClaimValue(string claimType)
        {
            var claimsPrincipal = Request.GetRequestContext().Principal as ClaimsPrincipal;
            if (claimsPrincipal == null)
                throw new ApplicationException("Não existem informações para obter os recursos necessários.");

            var claim = claimsPrincipal.Claims.SingleOrDefault(c => c.Type == claimType);
            if (claim == null) throw new ApplicationException("O recurso requisitado não existe.");
            return claim.Value;
        }
    }
}