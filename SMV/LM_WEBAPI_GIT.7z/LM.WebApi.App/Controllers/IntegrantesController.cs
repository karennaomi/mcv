﻿using LM.Core.Application;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace LM.WebApi.App.Controllers
{
    public class IntegrantesController : BaseApiController
    {
        private readonly IIntegranteAplicacao _appIntegrante;
        private readonly IPontoDemandaAplicacao _appPontoDemanda;
        public IntegrantesController(IIntegranteAplicacao appIntegrante, IUsuarioAplicacao appUsuario, IPontoDemandaAplicacao appPontoDemanda)
        {
            _appIntegrante = appIntegrante;
            _appPontoDemanda = appPontoDemanda;
        }

        public IEnumerable<IntegranteDTO> Get()
        {
            return _appPontoDemanda.Obter(ObterUsuarioId(), ObterPontoDemandaId()).IntegrantesAtivos().Select(i => new IntegranteDTO(i));
        }

        public IHttpActionResult Post(IntegranteDTO integranteDTO)
        {
            var integrante = _appIntegrante.Criar(ObterPontoDemandaId(), integranteDTO.ObterIntegrante());
            return Ok(new IntegranteDTO(integrante));
        }

        public IHttpActionResult Put(IntegranteDTO integranteDTO)
        {
            var integrante = _appIntegrante.Atualizar(ObterPontoDemandaId(), ObterUsuarioId(), integranteDTO.ObterIntegrante());
            return Ok(new IntegranteDTO(integrante));
        }

        [HttpPost]
        [Route("api/integrantes/desativar")]
        public void Desativar([FromBody]int id)
        {
            _appIntegrante.Desativar(ObterPontoDemandaId(), ObterUsuarioId(), id);
        }

        [HttpPost]
        [Route("api/integrantes/removerdoponto")]
        public void RemoverDoPonto([FromBody]int id)
        {
            _appIntegrante.RemoverDoPonto(ObterPontoDemandaId(), ObterUsuarioId(), id);
        }

        [HttpPost]
        [Route("api/integrantes/convidar")]
        public void Convidar([FromBody]int id)
        {
            _appIntegrante.Convidar(ObterPontoDemandaId(), ObterUsuarioId(), id, AppHelper.ImagemHost);
        }

        [HttpGet]
        [Route("api/integrantes/animais")]
        public IEnumerable<AnimalDTO> Animais()
        {
            return _appIntegrante.Animais().Select(a => new AnimalDTO(a));
        }
    }
}
