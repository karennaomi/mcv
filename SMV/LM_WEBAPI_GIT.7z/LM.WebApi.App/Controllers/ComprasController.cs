﻿using LM.Core.Application;
using LM.Core.Domain;
using LM.Core.Domain.CustomException;
using LM.WebApi.App.ExceptionHandling;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;

namespace LM.WebApi.App.Controllers
{
    public class ComprasController : BaseApiController
    {
        private readonly ICompraAtivaAplicacao _appCompraAtiva;
        private readonly ICompraAplicacao _appCompra;
        private readonly IUsuarioAplicacao _appUsuario;
        public ComprasController(ICompraAtivaAplicacao appCompraAtiva, ICompraAplicacao appCompra, IUsuarioAplicacao appUsuario)
        {
            _appCompraAtiva = appCompraAtiva;
            _appCompra = appCompra;
            _appUsuario = appUsuario;
        }

        [ResponseType(typeof(CompraDTO))]
        public IHttpActionResult Get(long id, int resolucaoId = ResolucaoIdPadrao)
        {
            var compra = _appCompra.Obter(ObterPontoDemandaId(), id);
            return Ok(new CompraDTO(compra, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost));
        }

        [ResponseType(typeof(CompraDTO))]
        public IHttpActionResult Post(CompraDTO compraDTO, int resolucaoId = ResolucaoIdPadrao)
        {
            if (!ModelState.IsValid) throw new ValidationException(ModelState);

            var usuario = _appUsuario.Obter(ObterUsuarioId());
            var compra = _appCompra.Criar(compraDTO.ObterCompra(usuario, ObterPontoDemandaId(), ObterClientApp()));
            return CreatedAtRoute("DefaultApi", new { id = compra.Id }, new CompraDTO(compra, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost));
        }

        [HttpPost]
        [Route("api/compras/ativar")]
        [ResponseType(typeof(CompraAtivaDTO))]
        public IHttpActionResult Ativar()
        {
            var compraAtiva = _appCompraAtiva.AtivarCompra(ObterUsuarioId(), ObterPontoDemandaId());
            return Ok(new CompraAtivaDTO(compraAtiva));
        }

        [HttpPost]
        [Route("api/compras/desativar")]
        [ResponseType(typeof(CompraAtivaDTO))]
        public IHttpActionResult Desativar()
        {
            var compraAtiva = _appCompraAtiva.DesativarCompra(ObterPontoDemandaId());
            return Ok(new CompraAtivaDTO(compraAtiva));
        }

        [HttpGet]
        [Route("api/compras/existecompraativa")]
        public bool ExisteCompraAtiva()
        {
            return _appCompraAtiva.ExisteCompraAtiva(ObterPontoDemandaId());
        }

        [HttpGet]
        [Route("api/compras/sugestao")]
        public IList<CompraItemDTO> CompraSugerida(int resolucaoId = ResolucaoIdPadrao)
        {
            var sugestao = _appCompra.ListarSugestao(ObterPontoDemandaId());
            return sugestao.Select(item => new CompraItemDTO(item, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost)).BlasterOrder().ToList();
        }

        [HttpGet]
        [Route("api/compras/obteritemporprodutoid")]
        public CompraItemDTO ObterItemPorProdutoId(long produtoId, int resolucaoId = ResolucaoIdPadrao)
        {
            var item = _appCompra.ListarSugestao(ObterPontoDemandaId()).FirstOrDefault(i => i.Produto.Id == produtoId);
            if (item == null) throw new ObjetoNaoEncontradoException("Item não encontrado.");
            return new CompraItemDTO(item, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost);
        }

        [HttpGet]
        [Route("api/compras/motivossubstituicao")]
        public IEnumerable<MotivoSubstituicaoDTO> MotivosSubstituicao()
        {
            var motivos = _appCompra.MotivosSubstituicao();
            return motivos.Select(m => new MotivoSubstituicaoDTO(m));
        }

        [HttpGet]
        [Route("api/compras/listarsubstitutos")]
        public IList<CompraItemDTO> ListarSubstitutos(long itemId, int resolucaoId = ResolucaoIdPadrao)
        {
            var substitutos = _appCompra.ListarItensSubstitutos(ObterPontoDemandaId(), itemId);
            return substitutos.Select(item => new CompraItemDTO(item, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost)).ToList();
        }
    }
}
