﻿using LM.Core.Application;
using LM.Core.Domain;
using LM.Core.Domain.CustomException;
using LM.WebApi.App.ExceptionHandling;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;

namespace LM.WebApi.App.Controllers
{
    public class PedidosController : BaseApiController
    {
        private readonly IPedidoAplicacao _appPedido;
        public PedidosController(IPedidoAplicacao appPedido)
        {
            _appPedido = appPedido;
        }

        public IList<ItemDTO> Get(int resolucaoId = ResolucaoIdPadrao)
        {
            var sugestao = _appPedido.ListarItens(ObterPontoDemandaId());
            return sugestao.Select(item => new ItemDTO(item, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost)).ToList();
        }

        [HttpGet]
        [Route("api/pedidos/obteritemporprodutoid")]
        public ItemDTO ObterItemPorProdutoId(long produtoId, int resolucaoId = ResolucaoIdPadrao)
        {
            var item = _appPedido.ListarItens(ObterPontoDemandaId()).FirstOrDefault(i => i.Produto.Id == produtoId && i.Status == StatusPedido.Pendente);
            if (item == null) throw new ObjetoNaoEncontradoException("Item não encontrado.");
            return new ItemDTO(item, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost);
        }

        [ResponseType(typeof(ItemDTO))]
        public IHttpActionResult Post(ItemDTO itemDTO)
        {
            var itemPedido = _appPedido.AdicionarItem(ObterPontoDemandaId(), itemDTO.ObterPedidoItem(ObterUsuarioId(), ObterPontoDemandaId(), ObterClientApp()));
            itemDTO.Id = itemPedido.Id;
            return Ok(itemDTO);
        }

        [ResponseType(typeof(ItemDTO))]
        public void Put(ItemDTO itemDTO)
        {
            if (!ModelState.IsValid) throw new ValidationException(ModelState);
            _appPedido.AtualizarQuantidadeDoItem(ObterPontoDemandaId(), ObterUsuarioId(), itemDTO.Id, itemDTO.QuantidadeSugestaoCompra);
        }

        public IHttpActionResult Delete(long id)
        {
            _appPedido.RemoverItem(ObterPontoDemandaId(), ObterUsuarioId(), id);
            return Ok();
        }

        [HttpGet]
        [Route("api/pedidos/todosstatus")]
        public IDictionary<int, StatusPedidoDTO> Status()
        {
            return new Dictionary<int, StatusPedidoDTO>
            {
                {(int) StatusPedido.Comprado, new StatusPedidoDTO(StatusPedido.Comprado)},
                {(int) StatusPedido.Rejeitado, new StatusPedidoDTO(StatusPedido.Rejeitado)},
                {(int) StatusPedido.Substituido, new StatusPedidoDTO(StatusPedido.Substituido)},
                {(int) StatusPedido.Pendente, new StatusPedidoDTO(StatusPedido.Pendente)}
            };
        }
    }
}
