﻿using LM.Core.Application;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace LM.WebApi.App.Controllers
{
    public class CategoriasController : BaseApiController
    {
        private readonly ICategoriaAplicacao _appCategoria;
        public CategoriasController(ICategoriaAplicacao appCategoria)
        {
            _appCategoria = appCategoria;
        }

        public IEnumerable<CategoriaDTO> Get(int secaoId, int resolucaoId = ResolucaoIdPadrao)
        {
            return _appCategoria.Listar(secaoId).Select(s => new CategoriaDTO(s, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost));
        }

        [HttpGet]
        [Route("api/categorias/secoes")]
        public IEnumerable<CategoriaDTO> Secoes(int resolucaoId = ResolucaoIdPadrao)
        {
            return _appCategoria.Secoes().Select(s => new CategoriaDTO(s, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost));
        }
    }
}
