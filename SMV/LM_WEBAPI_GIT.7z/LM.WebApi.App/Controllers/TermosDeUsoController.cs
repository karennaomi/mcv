﻿using LM.Core.Application;
using LM.Core.Domain;

namespace LM.WebApi.App.Controllers
{
    public class TermosDeUsoController : BaseApiController
    {
        private readonly IContratoAplicacao _appContrato;
        public TermosDeUsoController(IContratoAplicacao appContrato)
        {
            _appContrato = appContrato;
        }

        public Contrato Get()
        {
            return _appContrato.ObterAtivo();
        }
    }
}
