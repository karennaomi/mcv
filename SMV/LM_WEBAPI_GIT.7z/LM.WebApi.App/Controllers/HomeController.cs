﻿using System;
using System.Web.Http;

namespace LM.WebApi.App.Controllers
{
    public class HomeController : BaseApiController
    {
        public IHttpActionResult Get()
        {
            return Ok("Lista Mágica API");
        }
    }
}
