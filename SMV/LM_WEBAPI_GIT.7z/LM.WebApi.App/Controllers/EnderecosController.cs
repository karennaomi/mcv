﻿using LM.Core.Application;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace LM.WebApi.App.Controllers
{
    public class EnderecosController : BaseApiController
    {
        private readonly IEnderecoAplicacao _appEndereco;

        public EnderecosController(IEnderecoAplicacao appEndereco)
        {
            _appEndereco = appEndereco;
        }

        public EnderecoDTO Get(string cep)
        {
            return new EnderecoDTO(_appEndereco.BuscarPorCep(cep));
        }

        [HttpGet]
        [Route("api/enderecos/buscarporendereco")]
        public IEnumerable<EnderecoDTO> BuscarPorEndereco(string endereco)
        {
            var enderecos = _appEndereco.BuscarPorEndereco(endereco);
            return enderecos.Select(e => new EnderecoDTO(e));
        }

        [HttpGet]
        [Route("api/enderecos/buscarporponto")]
        public IEnumerable<EnderecoDTO> BuscarPorPonto(string lat, string lng)
        {
            var enderecos = _appEndereco.BuscarPorPonto(lat, lng);
            return enderecos.Select(e => new EnderecoDTO(e));
        }
    }
}
