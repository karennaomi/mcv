﻿using System.Web.Http.Description;
using LM.Core.Application;
using LM.Core.Domain.CustomException;
using LM.WebApi.App.ExceptionHandling;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace LM.WebApi.App.Controllers
{
    public class ListaItensController : BaseApiController
    {
        private readonly IListaAplicacao _appLista;
        private readonly IUsuarioAplicacao _appUsuario;
        public ListaItensController(IListaAplicacao appLista, IUsuarioAplicacao appUsuario)
        {
            _appLista = appLista;
            _appUsuario = appUsuario;
        }

        public IList<ItemDTO> Get(int resolucaoId = ResolucaoIdPadrao)
        {
            var sugestao = _appLista.ListarItens(ObterPontoDemandaId());
            return sugestao.Select(item => new ItemDTO(item, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost)).ToList();
        }

        [ResponseType(typeof(ItemDTO))]
        public IHttpActionResult Post(ItemDTO itemDTO, int resolucaoId = ResolucaoIdPadrao)
        {
            if (!ModelState.IsValid) throw new ValidationException(ModelState);
            var usuarioId = ObterUsuarioId();
            var pontoDemandaId = ObterPontoDemandaId();
            var item = _appLista.AdicionarItem(usuarioId, pontoDemandaId, itemDTO.ObterListaItem(usuarioId, pontoDemandaId, ObterClientApp()));
            return Ok(new ItemDTO(item, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost));
        }

        [ResponseType(typeof(ItemDTO))]
        public void Put(ItemDTO itemDTO)
        {
            if (!ModelState.IsValid) throw new ValidationException(ModelState);
            var usuario = _appUsuario.Obter(ObterUsuarioId());
            _appLista.AtualizarItem(ObterUsuarioId(), ObterPontoDemandaId(), itemDTO.ObterListaItem(usuario.Id, ObterPontoDemandaId(), ObterClientApp()));
        }

        [HttpGet]
        [Route("api/listaitens/obteritemporprodutoid")]
        public ItemDTO ObterItemPorProdutoId(long produtoId, int resolucaoId = ResolucaoIdPadrao)
        {
            var item = _appLista.ListarItens(ObterPontoDemandaId()).FirstOrDefault(i => i.Produto.Id == produtoId);
            if (item == null) throw new ObjetoNaoEncontradoException("Item não encontrado.");
            return new ItemDTO(item, ObterInterfaceId(), resolucaoId, AppHelper.ImagemHost);
        }

        [HttpPost]
        [Route("api/listaitens/desativar")]
        public void Desativar([FromBody] long id)
        {
            _appLista.DesativarItem(ObterUsuarioId(), ObterPontoDemandaId(), id);
        }

        [HttpGet]
        [Route("api/listaitens/periodosdeconsumo")]
        public IEnumerable<PeriodoDTO> PeriodosDeConsumo()
        {
            return _appLista.PeriodosDeConsumo().Select(p => new PeriodoDTO(p));
        }
    }
}
