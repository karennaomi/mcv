﻿using LM.Core.Application;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;

namespace LM.WebApi.App.Controllers
{
    public class LojasFavoritasController : BaseApiController
    {
        private readonly IPontoDemandaAplicacao _appPontoDemanda;
        private readonly IPlacesService _placeService;
        public LojasFavoritasController(IPontoDemandaAplicacao appPontoDemanda, IPlacesService placeService)
        {
            _appPontoDemanda = appPontoDemanda;
            _placeService = placeService;
        }

        public IEnumerable<LojaDTO> Get()
        {
            var pontoDemanda = _appPontoDemanda.Obter(ObterUsuarioId(), ObterPontoDemandaId());
            return pontoDemanda.LojasFavoritas.Select(l => new LojaDTO(l));
        }

        [ResponseType(typeof(LojaDTO))]
        public IHttpActionResult Post(LojaDTO lojaDTO)
        {
            var loja = _appPontoDemanda.AdicionarLojaFavorita(ObterUsuarioId(), ObterPontoDemandaId(), lojaDTO.ObterLoja());
            return CreatedAtRoute("DefaultApi", new { id = loja.Id }, new LojaDTO(loja));
        }

        public IHttpActionResult Delete(string localizadorId)
        {
            _appPontoDemanda.RemoverLojaFavorita(ObterUsuarioId(), ObterPontoDemandaId(), localizadorId);
            return Ok();
        }

        [HttpGet]
        [Route("api/lojasfavoritas/proximasdomeulocal")]
        public LojasProximasDTO ProximasDoMeuLocal(string nextPageToken = "")
        {
            var pontoDemanda = _appPontoDemanda.Obter(ObterUsuarioId(), ObterPontoDemandaId());
            return new LojasProximasDTO(_placeService.BuscarLojas(pontoDemanda.Endereco.Latitude.ToString(new CultureInfo("en-US")), pontoDemanda.Endereco.Longitude.ToString(new CultureInfo("en-US")), nextPageToken));
        }

        [HttpGet]
        [Route("api/lojasfavoritas/proximasdemim")]
        public LojasProximasDTO ProximasDeMim(string lat, string lng, string nextPageToken = "")
        {
            return new LojasProximasDTO(_placeService.BuscarLojas(lat, lng, nextPageToken));
        }

        [HttpGet]
        [Route("api/lojasfavoritas/detalhes")]
        public LojaDTO Detalhes(string localizadorId)
        {
            return new LojaDTO(_placeService.BuscarDetalheLoja(localizadorId));
        }
    }
}
