﻿using LM.Core.Application;
using LM.WebApi.App.ExceptionHandling;
using LM.WebApi.DTO;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;

namespace LM.WebApi.App.Controllers
{
    public class PontosDemandaController : BaseApiController
    {
        private readonly IPontoDemandaAplicacao _appPontoDemanda;

        public PontosDemandaController(IPontoDemandaAplicacao appPontoDemanda)
        {
            _appPontoDemanda = appPontoDemanda;
        }
        
        public PontoDemandaDTO Get()
        {
            return new PontoDemandaDTO(_appPontoDemanda.Obter(ObterUsuarioId(), ObterPontoDemandaId()));
        }

        [ResponseType(typeof(PontoDemandaDTO))]
        public IHttpActionResult Post(PontoDemandaDTO pontoDemandaDTO)
        {
            if (!ModelState.IsValid) throw new ValidationException(ModelState);

            var pontoDemanda = _appPontoDemanda.Criar(ObterUsuarioId(), pontoDemandaDTO.ObterPontoDemanda());
            return CreatedAtRoute("DefaultApi", null, new PontoDemandaDTO(pontoDemanda));
        }

        public IHttpActionResult Put(PontoDemandaDTO pontoDemandaDTO)
        {
            if (!ModelState.IsValid) throw new ValidationException(ModelState);

            var pontoDemanda = _appPontoDemanda.Atualizar(ObterUsuarioId(), pontoDemandaDTO.ObterPontoDemanda());
            return Ok(new PontoDemandaDTO(pontoDemanda));
        }

        [HttpPost]
        [Route("api/pontosdemanda/desativar")]
        public void Desativar([FromBody]long id)
        {
            _appPontoDemanda.Desativar(ObterUsuarioId(), id);
        }

        [HttpPost]
        [Route("api/pontosdemanda/removerintegrante")]
        public void RemoverIntegrante([FromBody]long id)
        {
            _appPontoDemanda.RemoverIntegrante(ObterUsuarioId(), ObterPontoDemandaId(), id);
        }

        [HttpGet]
        [Route("api/pontosdemanda/todos")]
        public IEnumerable<PontoDemandaDTO> All()
        {
            return _appPontoDemanda.Listar(ObterUsuarioId()).Select(p => new PontoDemandaDTO(p));
        }

        [HttpPost]
        [Route("api/pontosdemanda/definirfrequenciadecompra")]
        public IHttpActionResult DefinirFrequenciaDeCompra([FromBody]short frequencia)
        {
            var pontoDemanda = _appPontoDemanda.DefinirFrequenciaDeCompra(ObterUsuarioId(), ObterPontoDemandaId(), frequencia, AppHelper.ImagemHost);
            return Ok(new PontoDemandaDTO(pontoDemanda));
        }
    }
}
