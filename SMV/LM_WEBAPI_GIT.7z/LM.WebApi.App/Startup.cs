﻿using LM.WebApi.App.App_Start;
using LM.WebApi.App.Areas.HelpPage;
using Microsoft.Owin;
using Ninject.Web.Common.OwinHost;
using Ninject.Web.WebApi.OwinHost;
using Owin;
using System.Web.Http;
using System.Web.Mvc;

[assembly: OwinStartup(typeof(LM.WebApi.App.Startup))]

namespace LM.WebApi.App
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();
            AreaRegistration.RegisterAllAreas();
            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll); //Enabling CORS
            HelpPageConfig.Register(config);
            var kernel = NinjectConfig.CreateKernel();
            app.UseNinjectMiddleware(() => kernel);
            OAuthConfig.Configure(app, kernel);
            WebApiConfig.Register(config);
            app.UseNinjectWebApi(config);
        }
    }

    public class TestStartup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();
            var kernel = NinjectConfig.CreateKernel();
            app.UseNinjectMiddleware(() => kernel);
            OAuthConfig.Configure(app, kernel);
            WebApiConfig.Register(config);
            app.UseNinjectWebApi(config);
        }
    }
}
