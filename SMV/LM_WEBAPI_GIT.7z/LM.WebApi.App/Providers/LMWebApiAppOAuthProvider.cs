﻿using System;
using LM.Core.Domain.CustomException;
using LM.WebApi.App.AuthContext;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LM.WebApi.App.Providers
{
    public class LMWebApiAppOAuthProvider : OAuthAuthorizationServerProvider
    {
        private readonly IAuthProviderService _authProviderService;
        public LMWebApiAppOAuthProvider(IAuthProviderService clientAuthService)
        {
            _authProviderService = clientAuthService;
        }

        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            string clientId, clientSecret;
            if (!context.TryGetBasicCredentials(out clientId, out clientSecret))
            {
                context.TryGetFormCredentials(out clientId, out clientSecret);
            }

            try
            {
                var client = _authProviderService.AuthClient(clientId, clientSecret);
                context.OwinContext.Set("clientRefreshTokenLifeTime", client.RefreshTokenLifeTime.ToString());
                context.OwinContext.Set("clientId", clientId);
                return Task.FromResult(context.Validated());
            }
            catch (InvalidContextException ex)
            {
                context.SetError(ex.Key, ex.Message);
                return Task.FromResult(false);
            }
        }

        public override Task GrantClientCredentials(OAuthGrantClientCredentialsContext context)
        {
            if (!_authProviderService.ClientIdExist(context.ClientId)) return Task.FromResult(false);
            var identity = new ClaimsIdentity(context.Options.AuthenticationType);
            var authenticationTicket = new AuthenticationTicket(identity, new AuthenticationProperties());
            return Task.FromResult(context.Validated(authenticationTicket));
        }

        public override Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            try
            {
                var ticket = _authProviderService.CreateAuthTicket(context.UserName, context.Password, context.Options.AuthenticationType, context.ClientId);
                return Task.FromResult(context.Validated(ticket));
            }
            catch (LoginInvalidoException ex)
            {
                context.Response.StatusCode = 400;
                context.SetError("invalid_grant", ex.Message);
            }
            catch (ObjetoNaoEncontradoException ex)
            {
                context.Response.StatusCode = 404;
                context.SetError("invalid_grant", ex.Message);
            }
            return Task.FromResult(false);
            
        }

        public override Task GrantRefreshToken(OAuthGrantRefreshTokenContext context)
        {
            if (context.OwinContext.Get<string>("clientId") != context.ClientId)
            {
                context.SetError("invalid_client_id", "client_id inválido.");
                return Task.FromResult<object>(null);
            }

            try
            {
                var newTicket = _authProviderService.RenewAuthTicket(context.Ticket, context.Request.ReadFormAsync().Result["ponto_demanda_id"]);
                return Task.FromResult(context.Validated(newTicket));
            }
            catch (PontoDemandaInvalidoException ex)
            {
                context.SetError("invalid_ponto_demanda_id", ex.Message);
                return Task.FromResult(false); 
            }
        }

        public override Task TokenEndpoint(OAuthTokenEndpointContext context)
        {
            foreach (var property in context.Properties.Dictionary)
            {
                context.AdditionalResponseParameters.Add(property.Key, property.Value);
            }
            return Task.FromResult<object>(null);
        }
    }
}