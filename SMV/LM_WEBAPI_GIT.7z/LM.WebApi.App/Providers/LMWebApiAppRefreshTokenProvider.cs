﻿using LM.WebApi.App.AuthContext;
using LM.WebApi.App.Models;
using Microsoft.Owin.Security.Infrastructure;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace LM.WebApi.App.Providers
{
    public class LMWebApiAppRefreshTokenProvider : IAuthenticationTokenProvider
    {
        private readonly IAuthProviderService _authService;
        public LMWebApiAppRefreshTokenProvider(IAuthProviderService authService)
        {
            _authService = authService;
        }

        public void Create(AuthenticationTokenCreateContext context)
        {
            throw new NotImplementedException();
        }

        public async Task CreateAsync(AuthenticationTokenCreateContext context)
        {
            var clientid = context.OwinContext.Get<string>("clientId");
            if (string.IsNullOrEmpty(clientid)) return;

            var refreshTokenId = Guid.NewGuid().ToString("n");
            var refreshTokenLifeTime = context.OwinContext.Get<string>("clientRefreshTokenLifeTime");

            var userIdClaim = context.Ticket.Identity.Claims.SingleOrDefault(c => c.Type == LMClaimTypes.UsuarioId);
            var userId = userIdClaim == null ? 0 : long.Parse(userIdClaim.Value);

            var token = new AppRefreshToken
            {
                Id = refreshTokenId,
                ClientId = clientid,
                UserId = userId,
                IssuedUtc = DateTime.UtcNow,
                ExpiresUtc = DateTime.UtcNow.AddMinutes(Convert.ToDouble(refreshTokenLifeTime)),
                ProtectedTicket = context.SerializeTicket()
            };

            var result = _authService.AddRefreshToken(token);

            if (result)
            {
                context.SetToken(refreshTokenId);
            }
        }

        public async Task ReceiveAsync(AuthenticationTokenReceiveContext context)
        {
            var refreshToken = _authService.FindRefreshToken(context.Token);
            if (refreshToken != null)
            {
                //Get protectedTicket from refreshToken class
                context.DeserializeTicket(refreshToken.ProtectedTicket);
                _authService.RemoveRefreshToken(context.Token);
            } 
        }

        public void Receive(AuthenticationTokenReceiveContext context)
        {
            throw new NotImplementedException();
        }
    }
}