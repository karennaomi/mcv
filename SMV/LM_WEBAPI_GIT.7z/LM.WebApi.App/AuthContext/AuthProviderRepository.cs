﻿using System;
using System.Data.Entity;
using LM.WebApi.App.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LM.WebApi.App.AuthContext
{
    public interface IAuthProviderRepository : IDisposable
    {
        AppClient FindClient(string clientId);
        bool AddRefreshToken(AppRefreshToken token);
        bool RemoveRefreshToken(string refreshTokenId);
        bool RemoveRefreshToken(AppRefreshToken refreshToken);
        AppRefreshToken FindRefreshToken(string refreshTokenId);
        List<AppRefreshToken> GetAllRefreshTokens();
    }

    public class AuthProviderRepository : IAuthProviderRepository
    {
        private readonly LMWebApiAuthProviderContext _ctx = new LMWebApiAuthProviderContext();
        
        public AppClient FindClient(string clientId)
        {
            return _ctx.AppClients.Find(clientId);
        }

        public bool AddRefreshToken(AppRefreshToken token)
        {
            var existingTokens = _ctx.AppRefreshTokens.Where(r => r.UserId == token.UserId && r.ClientId == token.ClientId).ToList();
            if (existingTokens.Any()) existingTokens.ForEach(t => RemoveRefreshToken(t));
            
            _ctx.AppRefreshTokens.Add(token);
            return _ctx.SaveChanges() > 0 ;
        }

        public bool RemoveRefreshToken(string refreshTokenId)
        {
            var refreshToken = _ctx.AppRefreshTokens.Find(refreshTokenId);
            if (refreshToken == null) return false;
            
            _ctx.AppRefreshTokens.Remove(refreshToken);
            return _ctx.SaveChanges() > 0;
        }

        public bool RemoveRefreshToken(AppRefreshToken refreshToken)
        {
            _ctx.AppRefreshTokens.Remove(refreshToken);
            return _ctx.SaveChanges() > 0;
        }

        public AppRefreshToken FindRefreshToken(string refreshTokenId)
        {
            return _ctx.AppRefreshTokens.Find(refreshTokenId);
        }

        public List<AppRefreshToken> GetAllRefreshTokens()
        {
            return _ctx.AppRefreshTokens.ToList();
        }

        public void Dispose()
        {
            _ctx.Dispose();
        }
    }
}