﻿using System;

namespace LM.WebApi.App.AuthContext
{
    public class InvalidContextException : ApplicationException
    {
        public string Key { get; set; }

        public InvalidContextException(string key, string message) : base(message)
        {
            Key = key;
        }
    }
}