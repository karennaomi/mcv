﻿using LM.WebApi.App.Models;
using System.Data.Entity;

namespace LM.WebApi.App.AuthContext
{
    public class LMWebApiAuthProviderContext : DbContext
    {
        public DbSet<AppClient> AppClients { get; set; }
        public DbSet<AppRefreshToken> AppRefreshTokens { get; set; }

        public LMWebApiAuthProviderContext() : base("SOL")
        {
            Database.SetInitializer<LMWebApiAuthProviderContext>(null);
        }
    }
}