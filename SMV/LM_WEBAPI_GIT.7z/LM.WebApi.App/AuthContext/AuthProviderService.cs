﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using LM.Core.Application;
using LM.Core.Domain;
using LM.Core.Domain.CustomException;
using LM.WebApi.App.Models;
using System.Threading.Tasks;
using Microsoft.Owin.Security;

namespace LM.WebApi.App.AuthContext
{
    public interface IAuthProviderService
    {
        AppClient AuthClient(string clientId, string clientSecret);
        bool ClientIdExist(string clientId);
        bool AddRefreshToken(AppRefreshToken token);
        AppRefreshToken FindRefreshToken(string tokenId);
        bool RemoveRefreshToken(string tokenId);

        AuthenticationTicket CreateAuthTicket(string userName, string password, string authType, string clientId);
        AuthenticationTicket RenewAuthTicket(AuthenticationTicket ticket, string pontoDemandaIdValue);      
    }

    public class AuthProviderService : IAuthProviderService
    {
        private readonly IAuthProviderRepository _repo;
        private readonly IUsuarioAplicacao _appUsuario;
        private readonly IPontoDemandaAplicacao _appPontoDemanda;
        public AuthProviderService(IAuthProviderRepository repo, IUsuarioAplicacao appUsuario, IPontoDemandaAplicacao appPontoDemanda)
        {
            _repo = repo;
            _appUsuario = appUsuario;
            _appPontoDemanda = appPontoDemanda;
        }

        public AppClient AuthClient(string clientId, string clientSecret)
        {
            if (string.IsNullOrWhiteSpace(clientId)) throw new InvalidContextException("client_id", "client_id precisa ser enviado.");
            var client = _repo.FindClient(clientId);
            if (client == null) throw new InvalidContextException("client_id", string.Format("Cliente '{0}' não cadastrado no sistema.", clientId));
            if (client.ApplicationType == AppTypes.NativeConfidential) ValidatesNativeConfidential(client, clientSecret);
            if (!client.Active) throw new InvalidContextException("client_id", "Cliente desativado.");
            return client;
        }

        public bool ClientIdExist(string clientId)
        {
            if (string.IsNullOrWhiteSpace(clientId)) return false;
            var client = _repo.FindClient(clientId);
            return client != null;
        }

        public bool AddRefreshToken(AppRefreshToken token)
        {
            token.Id = AppClientHelper.GetHash(token.Id);
            return _repo.AddRefreshToken(token);
        }

        private static void ValidatesNativeConfidential(AppClient client, string clientSecret)
        {
            if (string.IsNullOrWhiteSpace(clientSecret)) throw new InvalidContextException("client_secret", "client_secret precisa ser enviado.");
            if (client.Secret != AppClientHelper.GetHash(clientSecret)) throw new InvalidContextException("client_secret", "client_secret inválido.");
        }

        public AppRefreshToken FindRefreshToken(string tokenId)
        {
            var hashedTokenId = AppClientHelper.GetHash(tokenId);
            return _repo.FindRefreshToken(hashedTokenId);
        }

        public bool RemoveRefreshToken(string tokenId)
        {
            var hashedTokenId = AppClientHelper.GetHash(tokenId);
            return _repo.RemoveRefreshToken(hashedTokenId);
        }

        public AuthenticationTicket CreateAuthTicket(string userName, string password, string authType, string clientId)
        {
            var usuario = _appUsuario.ValidarLogin(userName, password);

            var pontoDemandaId = 0L;
            var pontosDemanda = _appPontoDemanda.Listar(usuario.Id);
            if (pontosDemanda.Any())
            {
                pontoDemandaId = pontosDemanda.First().Id; 
            }

            var oAuthIdentity = new ClaimsIdentity(authType);
            oAuthIdentity.AddClaim(new Claim(LMClaimTypes.UsuarioId, usuario.Id.ToString()));
            oAuthIdentity.AddClaim(new Claim(LMClaimTypes.PontoDemandaId, pontoDemandaId.ToString()));
            oAuthIdentity.AddClaim(new Claim(LMClaimTypes.InterfaceId, clientId));

            return new AuthenticationTicket(oAuthIdentity, CreateProperties(usuario, clientId));
        }

        public AuthenticationTicket RenewAuthTicket(AuthenticationTicket ticket, string pontoDemandaIdValue)
        {
            if(string.IsNullOrWhiteSpace(pontoDemandaIdValue)) throw new PontoDemandaInvalidoException("Id do ponto de demanda inválido.");

            var newIdentity = new ClaimsIdentity(ticket.Identity);
            
            var pontoDemandaClaim = newIdentity.Claims.Single(c => c.Type == LMClaimTypes.PontoDemandaId);
            newIdentity.RemoveClaim(pontoDemandaClaim);
            
            var usuarioId = long.Parse(newIdentity.Claims.Single(c => c.Type == LMClaimTypes.UsuarioId).Value);
            var pontoDemandaId = _appPontoDemanda.VerificarPontoDemanda(usuarioId, long.Parse(pontoDemandaIdValue));
            
            newIdentity.AddClaim(new Claim(LMClaimTypes.PontoDemandaId, pontoDemandaId.ToString()));

            return new AuthenticationTicket(newIdentity, ticket.Properties);
        }

        private static AuthenticationProperties CreateProperties(Usuario usuario, string clientId)
        {
            var data = new Dictionary<string, string>
            {
                { "user_name", usuario.Integrante.Nome },
                { "user_email", usuario.Integrante.Email },
            };
            return new AuthenticationProperties(data);
        }
    }
}