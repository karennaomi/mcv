﻿using System.Configuration;

namespace LM.WebApi.App
{
    public class AppHelper
    {
        public static string UrlTrocarSenha
        {
            get { return ConfigurationManager.AppSettings["UrlTrocarSenha"]; }
        }

        public static bool AllowInsecureHttp
        {
            get { return bool.Parse(ConfigurationManager.AppSettings["AllowInsecureHttp"]); }
        }

        public static string PushServiceHost
        {
            get { return ConfigurationManager.AppSettings["PushServiceHost"]; }
        }

        public static string GoogleGeocodeHost
        {
            get { return ConfigurationManager.AppSettings["GoogleGeocodeHost"]; }
        }

        public static string GooglePlaceHost
        {
            get { return ConfigurationManager.AppSettings["GooglePlaceHost"]; }
        }

        public static string GoogleApiKey
        {
            get { return ConfigurationManager.AppSettings["GoogleApiKey"]; }
        }

        public static string ImagemHost
        {
            get { return ConfigurationManager.AppSettings["ImagemHost"]; }
        }
    }
}