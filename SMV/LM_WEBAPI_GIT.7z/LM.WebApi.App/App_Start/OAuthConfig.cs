﻿using System.Configuration;
using LM.WebApi.App.AuthContext;
using LM.WebApi.App.Providers;
using Microsoft.Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using Ninject;
using Owin;
using System;

namespace LM.WebApi.App
{
    public class OAuthConfig
    {
        public static void Configure(IAppBuilder app, IKernel kernel)
        {
            var oAuthOptions = new OAuthAuthorizationServerOptions
            {
                TokenEndpointPath = new PathString("/api/token"),
                Provider = new LMWebApiAppOAuthProvider(kernel.Get<IAuthProviderService>()),
                RefreshTokenProvider = new LMWebApiAppRefreshTokenProvider(kernel.Get<IAuthProviderService>()),
                AccessTokenExpireTimeSpan = TimeSpan.FromDays(1),
                AllowInsecureHttp = AppHelper.AllowInsecureHttp,
                AuthenticationMode = AuthenticationMode.Active,
            };

            app.UseOAuthBearerTokens(oAuthOptions);

            // Uncomment the following lines to enable logging in with third party login providers
            //app.UseMicrosoftAccountAuthentication(
            //    clientId: "",
            //    clientSecret: "");

            //app.UseTwitterAuthentication(
            //    consumerKey: "",
            //    consumerSecret: "");

            //app.UseFacebookAuthentication(
            //    appId: "",
            //    appSecret: "");

            //app.UseGoogleAuthentication();
        }
    }
}
