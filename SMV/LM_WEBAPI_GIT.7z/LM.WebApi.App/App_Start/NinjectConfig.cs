﻿using System.Collections.Generic;
using LM.Core.Application;
using LM.Core.Domain.Repositorio;
using LM.Core.Domain.Servicos;
using LM.Core.RepositorioEF;
using LM.WebApi.App.AuthContext;
using Ninject;
using System.Reflection;

namespace LM.WebApi.App.App_Start
{
    public class NinjectConfig
    {
        public static StandardKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());
            RegisterBinds(kernel);
            return kernel;
        }

        private static void RegisterBinds(StandardKernel kernel)
        {
            kernel.Bind<IAuthProviderService>().To<AuthProviderService>();
            kernel.Bind<IAuthProviderRepository>().To<AuthProviderRepository>();

            kernel.Bind<IUsuarioAplicacao>().To<UsuarioAplicacao>();
            kernel.Bind<IRepositorioUsuario>().To<UsuarioEF>();

            kernel.Bind<ICategoriaAplicacao>().To<CategoriaAplicacao>();
            kernel.Bind<IRepositorioCategoria>().To<CategoriaEF>();

            kernel.Bind<IPontoDemandaAplicacao>().To<PontoDemandaAplicacao>();
            kernel.Bind<IRepositorioPontoDemanda>().To<PontoDemandaEF>();

            kernel.Bind<IListaAplicacao>().To<ListaAplicacao>();
            kernel.Bind<IRepositorioLista>().To<ListaEF>();

            kernel.Bind<IPedidoAplicacao>().To<PedidoAplicacao>();
            kernel.Bind<IRepositorioPedido>().To<PedidoEF>();

            kernel.Bind<IProdutoAplicacao>().To<ProdutoAplicacao>();
            kernel.Bind<IRepositorioProduto>().To<ProdutoEF>();

            kernel.Bind<ICompraAtivaAplicacao>().To<CompraAtivaAplicacao>();
            kernel.Bind<IRepositorioCompraAtiva>().To<CompraAtivaEF>();

            kernel.Bind<ICompraAplicacao>().To<CompraAplicacao>();
            kernel.Bind<IRepositorioCompra>().To<CompraEF>();

            kernel.Bind<ITemplateMensagemAplicacao>().To<TemplateMensagemAplicacao>();
            kernel.Bind<IRepositorioTemplateMensagem>().To<TemplateMensagemEF>();

            kernel.Bind<IServicoRest>().To<RestServiceWithRestSharp>().Named("PushService").WithConstructorArgument("host", AppHelper.PushServiceHost);
            kernel.Bind<IServicoRest>().To<RestServiceWithRestSharp>().Named("GoogleGeocodeService").WithConstructorArgument("host", AppHelper.GoogleGeocodeHost);
            kernel.Bind<IServicoRest>().To<RestServiceWithRestSharp>().Named("GooglePlaceService").WithConstructorArgument("host", AppHelper.GooglePlaceHost);

            kernel.Bind<INotificacaoAplicacao>().To<NotificacaoAplicacao>();

            kernel.Bind<IRecuperarSenhaAplicacao>().To<RecuperarSenhaAplicacao>();
            kernel.Bind<IRepositorioRecuperarSenha>().To<RecuperarSenhaEF>();

            kernel.Bind<IFilaItemAplicacao>().To<FilaItemAplicacao>();
            kernel.Bind<IRepositorioFilaItem>().To<FilaItemEF>();

            kernel.Bind<IIntegranteAplicacao>().To<IntegranteAplicacao>();
            kernel.Bind<IRepositorioIntegrante>().To<IntegranteEF>();

            kernel.Bind<IContratoAplicacao>().To<ContratoAplicacao>();
            kernel.Bind<IRepositorioContrato>().To<ContratoEF>();

            kernel.Bind<IRepositorioProcedures>().To<Procedures>();

            kernel.Bind<IPlacesService>().To<GooglePlaceService>().WithConstructorArgument("key", AppHelper.GoogleApiKey);

            kernel.Bind<IEnderecoAplicacao>().To<EnderecoAplicacao>();
            kernel.Bind<ICepAplicacao>().To<EnderecoCorreiosService>();
            kernel.Bind<IRepositorioCorreios>().To<CorreiosEF>();

            kernel.Bind<IUnitOfWork>().To<UnitOfWorkEF>();
        }
    }
}
