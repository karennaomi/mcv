﻿
namespace LM.WebApi.App.Models
{
    public enum AppTypes
    {
        JavaScript = 0,
        NativeConfidential = 1
    };
}