﻿
namespace LM.WebApi.App.Models
{
    public class LMClaimTypes
    {
        public static string UsuarioId = "http://listamagica.com.br/claims/usuarioid";
        public static string PontoDemandaId = "http://listamagica.com.br/claims/pontodemandaid";
        public static string InterfaceId = "http://listamagica.com.br/claims/interfaceid";
    }
}