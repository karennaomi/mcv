﻿using System;
using LM.Core.Domain;

namespace LM.WebApi.App.Models
{
    public class RecuperarSenhaDTO
    {
        public RecuperarSenhaDTO(RecuperarSenha recuperarSenha)
        {
            Token = recuperarSenha.Token;
            DataExpiracao = recuperarSenha.DataExpiracao;
        }

        public Guid Token { get; set; }
        public DateTime DataExpiracao { get; set; }
    }
}