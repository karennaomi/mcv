﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LM.WebApi.App.Models
{
    public class AppRefreshToken
    {
        [Key]
        public string Id { get; set; }
        [Required]
        public long UserId { get; set; }
        [Required]
        [MaxLength(50)]
        public string ClientId { get; set; }
        public DateTime IssuedUtc { get; set; }
        public DateTime ExpiresUtc { get; set; }
        [Required]
        public string ProtectedTicket { get; set; }
    }
}