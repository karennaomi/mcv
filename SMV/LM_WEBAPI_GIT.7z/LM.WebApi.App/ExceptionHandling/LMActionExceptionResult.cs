﻿using LM.Core.Domain.CustomException;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;

namespace LM.WebApi.App.ExceptionHandling
{
    public class LMActionExceptionResult : IHttpActionResult
    {
        public HttpRequestMessage Request { get; set; }
        public Exception Exception { get; set; }

        public LMActionExceptionResult(HttpRequestMessage request, Exception ex)
        {
            Request = request;
            Exception = ex;
        }

        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            var response = new HttpResponseMessage {RequestMessage = Request};

            if (Exception is DbEntityValidationException)
            {
                var dbException = Exception as DbEntityValidationException;
                var errors = (from entityError in dbException.EntityValidationErrors 
                                from validationError in entityError.ValidationErrors 
                                    select new KeyValuePair<string, string>(validationError.PropertyName, validationError.ErrorMessage)).ToList();

                response.StatusCode = HttpStatusCode.BadRequest;
                response.Content = ErrorResult.ToStringContent("Erro de validação.", "Ocorreram erros de validação. Por favor analise os erros e reenvie sua requisição.", errors);
            }
            else if (Exception is ValidationException)
            {
                response.StatusCode = HttpStatusCode.BadRequest;
                var ex = Exception as ValidationException;
                response.Content = ErrorResult.ToStringContent("Erro de validação.", "Ocorreram erros de validação. Por favor analise os erros e reenvie sua requisição.", ex.GetErrors());
            }
            else if (Exception is PropertyException)
            {
                response.StatusCode = HttpStatusCode.BadRequest;
                var ex = Exception as PropertyException;
                var error = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>(ex.Property, ex.Message)
                };
                response.Content = ErrorResult.ToStringContent("Erro de validação.", "Ocorreram erros de validação. Por favor analise os erros e reenvie sua requisição.", error);
            }
            else if (Exception is ObjetoNaoEncontradoException)
            {
                response.StatusCode = HttpStatusCode.NotFound;
                response.Content = ErrorResult.ToStringContent("Recurso não encontrado.", Exception.Message);
            }
            else if (Exception is ApplicationException)
            {
                response.StatusCode = HttpStatusCode.BadRequest;
                response.Content = ErrorResult.ToStringContent("Ocorreu um erro na sua requisição.", Exception.Message);
            }
            else
            {
                response.StatusCode = HttpStatusCode.InternalServerError;
                response.Content = ErrorResult.ToStringContent("Ocorreu um erro inesperado.", "Ocorreu um erro imprevisto, sua requisição foi logada e sera analisada.");
            }
            return Task.FromResult(response);
        }

        [Serializable]
        private class ErrorStruct
        {
            [JsonProperty("error")]
            public string Error { get; set; }
            [JsonProperty("error_description")]
            public string ErrorDescription { get; set; }
            [JsonProperty("errors")]
            public IEnumerable<KeyValuePair<string, string>> Errors { get; set; }
        }

        private static class ErrorResult
        {
            public static StringContent ToStringContent(string error, string errorDescription, IEnumerable<KeyValuePair<string, string>> errors = null)
            {
                var errorStruct = new ErrorStruct
                {
                    Error = error,
                    ErrorDescription = errorDescription,
                    Errors = errors
                };
                return new StringContent(JsonConvert.SerializeObject(errorStruct, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore}));
            }
        }
    }
}