﻿using System;
using System.Collections.Generic;
using System.Web.Http.ModelBinding;

namespace LM.WebApi.App.ExceptionHandling
{
    public class ValidationException : ApplicationException
    {
        private readonly ModelStateDictionary _modelStateDictionary;

        public ValidationException(ModelStateDictionary modelState)
        {
            _modelStateDictionary = modelState;
        }

        public IEnumerable<KeyValuePair<string, string>> GetErrors()
        {
            foreach (var modelState in _modelStateDictionary)
            {
                foreach (var error in modelState.Value.Errors)
                {
                    yield return new KeyValuePair<string, string>(modelState.Key, error.ErrorMessage);
                }
            }
        }
    }
}