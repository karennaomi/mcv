﻿using System;
using System.Web;
using System.Web.Http.ExceptionHandling;
using Elmah;

namespace LM.WebApi.App.ExceptionHandling
{
    public class LMWebApiExceptionLogger : ExceptionLogger
    {
        public override void Log(ExceptionLoggerContext context)
        {
            // Wrap the exception in an HttpUnhandledException so that ELMAH can capture the original error page.
            Exception exceptionToRaise = new HttpUnhandledException(null, context.Exception);
            // Send the exception to ELMAH (for logging, mailing, filtering, etc.).
            ErrorSignal.FromCurrentContext().Raise(exceptionToRaise);
        }
    }
}