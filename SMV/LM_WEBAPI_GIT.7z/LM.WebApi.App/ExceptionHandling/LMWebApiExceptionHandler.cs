﻿using System.Web.Http.ExceptionHandling;

namespace LM.WebApi.App.ExceptionHandling
{
    public class LMWebApiExceptionHandler : ExceptionHandler
    {
        public override void Handle(ExceptionHandlerContext context)
        {
            context.Result = new LMActionExceptionResult(context.Request, context.Exception);
            base.Handle(context);
        }
    }
}