﻿using LM.PushService.WebApi.Models;
using PushSharp;
using PushSharp.Android;
using System.Configuration;

namespace LM.PushService.WebApi.Lib
{
    public class GooglePusher : LMPusher
    {
        private readonly string _apiKey = ConfigurationManager.AppSettings["GoogleApiKey"];

        public GooglePusher()
        {
            PushBroker.RegisterGcmService(new GcmPushChannelSettings(_apiKey));
        }

        public override void SendPushNotification(PushMessage message)
        {
            var notification = new GcmNotification()
                .ForDeviceRegistrationId(message.DeviceId)
                .WithJson("{\"alert\":\"" + message.Message + "\"}");
            
            PushBroker.QueueNotification(notification);
        }
    }
}
