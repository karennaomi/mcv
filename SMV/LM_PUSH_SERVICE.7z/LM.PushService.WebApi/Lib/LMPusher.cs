﻿using LM.PushService.WebApi.Models;
using PushSharp;
using System;

namespace LM.PushService.WebApi.Lib
{
    public abstract class LMPusher
    {
        protected PushBroker PushBroker { get; set; }
        protected LMPusher()
        {
            PushBroker = new PushBroker();

            PushBroker.OnChannelCreated += ChannelCreated;
            PushBroker.OnChannelDestroyed += ChannelDestroyed;
            PushBroker.OnChannelException += ChannelException;
            PushBroker.OnDeviceSubscriptionChanged += DeviceSubscriptionChanged;
            PushBroker.OnDeviceSubscriptionExpired += DeviceSubscriptionExpired;
            PushBroker.OnNotificationFailed += NotificationFailed;
            PushBroker.OnNotificationSent += NotificationSent;
            PushBroker.OnServiceException += ServiceException;
        }

        private static void ChannelCreated(object sender, PushSharp.Core.IPushChannel pushChannel)
        {
            Console.WriteLine("Channel Created for: " + sender);
        }

        private static void ChannelDestroyed(object sender)
        {
            Console.WriteLine("Channel Destroyed for: " + sender);
        }

        private static void ChannelException(object sender, PushSharp.Core.IPushChannel pushChannel, Exception exception)
        {
            Console.WriteLine("Channel Exception: " + sender + " -> " + exception);
        }

        private static void DeviceSubscriptionChanged(object sender, string oldSubscriptionId, string newSubscriptionId, PushSharp.Core.INotification notification)
        {
            //Currently this event will only ever happen for Android GCM
            Console.WriteLine("Device Registration Changed:  Old-> " + oldSubscriptionId + "  New-> " + newSubscriptionId + " -> " + notification);
        }

        private static void DeviceSubscriptionExpired(object sender, string expiredSubscriptionId, System.DateTime expirationDateUtc, PushSharp.Core.INotification notification)
        {
            Console.WriteLine("Device Subscription Expired: " + sender + " -> " + expiredSubscriptionId);
        }

        private static void NotificationFailed(object sender, PushSharp.Core.INotification notification, Exception exception)
        {
            Console.WriteLine("Failure: " + sender + " -> " + exception.Message + " -> " + notification);
        }

        private static void NotificationSent(object sender, PushSharp.Core.INotification notification)
        {
            Console.WriteLine("Sent: " + sender + " -> " + notification);
        }

        private static void ServiceException(object sender, System.Exception exception)
        {
            Console.WriteLine("Service Exception: " + sender + " -> " + exception);
        }

        public abstract void SendPushNotification(PushMessage message);

        public void StopAllServices()
        {
            PushBroker.StopAllServices();
        }
    }
}
