﻿using LM.PushService.WebApi.Models;

namespace LM.PushService.WebApi.Lib
{
    public interface ILMPusherService
    {
        void SendPushMessage(PushMessage message);
    }

    public class LMPusherService : ILMPusherService
    {
        public void SendPushMessage(PushMessage message)
        {
            var pusher = LMPusherFactory.GetPusher(message.DeviceType);
            pusher.SendPushNotification(message);
            pusher.StopAllServices();
        }
    }
}
