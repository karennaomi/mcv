﻿using System;
using System.Configuration;
using System.IO;
using LM.PushService.WebApi.Models;
using PushSharp;
using PushSharp.Apple;

namespace LM.PushService.WebApi.Lib
{
    public class ApplePusher : LMPusher
    {
        private readonly string _certFile = ConfigurationManager.AppSettings["AppleCertFile"];
        private readonly string _certPassword = ConfigurationManager.AppSettings["AppleCertPassword"];
        private readonly bool _isProduction = bool.Parse(ConfigurationManager.AppSettings["AppleIsProduction"]);
        
        public ApplePusher()
        {
            var appleCert = File.ReadAllBytes(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "../Cert", _certFile));
            PushBroker.RegisterAppleService(new ApplePushChannelSettings(_isProduction, appleCert, _certPassword));
        }

        public override void SendPushNotification(PushMessage message)
        {
            PushBroker.QueueNotification(new AppleNotification()
                .ForDeviceToken(message.DeviceId)
                .WithAlert(new AppleNotificationAlert
                {
                    Body = message.Message,
                    LocalizedKey = message.Message,
                    ActionLocalizedKey = message.Action
                })
                
            );
        }
    }
}
