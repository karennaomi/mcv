﻿using System;
using LM.PushService.WebApi.Lib;

namespace LM.PushService.WebApi.Lib
{
    public class LMPusherFactory
    {
        public static LMPusher GetPusher(string platformType)
        {
            switch (platformType.ToLower())
            {
                case "google":return new GooglePusher();
                case "apple":return new ApplePusher();
                default:throw new ApplicationException("Plataforma inválida: " + platformType);
            }
        }
    }
}
