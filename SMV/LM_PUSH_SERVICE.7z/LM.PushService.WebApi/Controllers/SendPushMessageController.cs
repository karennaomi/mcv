﻿using LM.PushService.WebApi.Lib;
using LM.PushService.WebApi.Models;
using System.Web.Http;

namespace LM.PushService.WebApi.Controllers
{
    public class SendPushMessageController : ApiController
    {
        private readonly ILMPusherService _lmPushService = new LMPusherService();

        public string Get()
        {
            return "Lista Mágica Push Service";
        }

        public void Post(PushMessage pushMessage)
        {
            _lmPushService.SendPushMessage(pushMessage);
        }
    }
}
