﻿
namespace LM.PushService.WebApi.Models
{
    public class PushMessage
    {
        public string DeviceId { get; set; }
        public string DeviceType { get; set; }
        public string Message { get; set; }
        public string Action { get; set; }
    }
}
