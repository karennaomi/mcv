﻿
namespace LM.PushService.WebApi.Models
{
    public enum PlatformType
    {
        Google, Apple
    }
}
