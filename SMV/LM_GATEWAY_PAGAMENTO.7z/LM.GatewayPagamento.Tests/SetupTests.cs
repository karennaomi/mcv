﻿using LM.GatewayPagamento.Service.Data.EntityFramework;
using LM.GatewayPagamento.Tests.Migrations;
using NUnit.Framework;
using System.Data.Entity;
using System.Data.Entity.Migrations;

namespace LM.GatewayPagamento.Tests
{
    [SetUpFixture]
    public class SetupTests
    {
        [SetUp]
        public void RunBeforeAnyTests()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<GatewayPagamentoContext, Configuration>());
            var contexto = new GatewayPagamentoContext();
            Database.Delete(contexto.Database.Connection);
            var migrator = new DbMigrator(new Configuration());
            migrator.Update();
        }

        [TearDown]
        public void RunAfterAnyTests()
        {
        }
    }
}
