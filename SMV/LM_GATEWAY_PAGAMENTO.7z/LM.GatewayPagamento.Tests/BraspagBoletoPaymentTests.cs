﻿using NUnit.Framework;

namespace LM.GatewayPagamento.Tests
{
    [TestFixture]
    public class BraspagBoletoPaymentTests
    {
    }
}
