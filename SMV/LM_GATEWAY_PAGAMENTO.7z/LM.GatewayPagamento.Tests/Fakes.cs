﻿using System;
using LM.GatewayPagamento.Service.Models.Enum;
using LM.GatewayPagamento.Service.Models.Order;
using LM.GatewayPagamento.Service.Models.Payment;

namespace LM.GatewayPagamento.Tests
{
    public class Fakes
    {
        public BraspagCreditcardPayment BraspagCreditcardPayment(string expirationDate = "05/2018")
        {
            return new BraspagCreditcardPayment(CreditcardType.Simulado)
            {
                Amount = 100.65M,
                ExpirationDate = expirationDate,
                CardHolder = "Joe Doe",
                CardNumber = "5151515151515151",
                SecurityCode = "123"
            };
        }

        public BraspagOrderRequest BraspagOrderResquest(string creditcardNumber)
        {
            var appOrderId = new Random().Next(1, int.MaxValue);
            var creditcard = BraspagCreditcardPayment();
            creditcard.CardNumber = creditcardNumber;

            return new BraspagOrderRequest
            {
                CustomerDocument = "12345678901",
                CustomerName = "Joe Doe",
                AppName = "GatewayTest",
                AppOrderId = appOrderId,
                Payment = creditcard
            };
        }
    }
}
