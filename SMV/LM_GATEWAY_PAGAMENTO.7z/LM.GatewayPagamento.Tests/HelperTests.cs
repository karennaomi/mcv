﻿using LM.GatewayPagamento.Service.Models;
using NUnit.Framework;

namespace LM.GatewayPagamento.Tests
{
    [TestFixture]
    public class HelperTests
    {
        [Test]
        public void TransformDecimalAmountInLongAmount()
        {
            Assert.AreEqual(10000L, Helper.ConvertAmountToLong(100M));
        }
        
        [Test]
        public void TransformDecimalAmountInLongAmountWithDecimalPlaces()
        {
            Assert.AreEqual(10060L, Helper.ConvertAmountToLong(100.60M));
        }

        [Test]
        public void TransformLongAmountInDecimalAmount()
        {
            Assert.AreEqual(100M, Helper.ConvertAmountToDecimal(10000L));
        }

        [Test]
        public void TransformLongAmountInDecimalAmountWithDecimalPlaces()
        {
            Assert.AreEqual(100.60M, Helper.ConvertAmountToDecimal(10060L));
        }
    }
}
