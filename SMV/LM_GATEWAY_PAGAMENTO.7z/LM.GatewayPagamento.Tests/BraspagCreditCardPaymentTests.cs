﻿using LM.GatewayPagamento.Service.Braspag.Pagador.Service;
using LM.GatewayPagamento.Service.Models.Payment;
using NUnit.Framework;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace LM.GatewayPagamento.Tests
{
    [TestFixture]
    public class BraspagCreditcardPaymentTests
    {
        private readonly Fakes _fakes;
        public BraspagCreditcardPaymentTests()
        {
            _fakes = new Fakes();
        }

        [Test]
        public void ValidatesValidMonth()
        {
            var creditcard = _fakes.BraspagCreditcardPayment();
            bool result;
            var validationResults = CreateValidationResults(creditcard, out result);
            Assert.IsTrue(result);
        }
        
        [Test]
        public void DontValidateMonthGreaterThan12()
        {
            var creditcard = _fakes.BraspagCreditcardPayment("13/2018");
            bool result;
            var validationResults = CreateValidationResults(creditcard, out result);
            AssertInvalidResult(result, validationResults);
        }

        [Test]
        public void DontValidateMonthLessThan01()
        {
            var creditcard = _fakes.BraspagCreditcardPayment("00/2018");
            bool result;
            var validationResults = CreateValidationResults(creditcard, out result);
            AssertInvalidResult(result, validationResults);
        }

        [Test]
        public void DontValidateYearWithLessThanFourChars()
        {
            var creditcard = _fakes.BraspagCreditcardPayment("05/18");
            bool result;
            var validationResults = CreateValidationResults(creditcard, out result);
            AssertInvalidResult(result, validationResults);
        }

        [Test]
        public void DontValidateYearWithMoreThanFourChars()
        {
            var creditcard = _fakes.BraspagCreditcardPayment("05/20188");
            bool result;
            var validationResults = CreateValidationResults(creditcard, out result);
            AssertInvalidResult(result, validationResults);
        }

        [Test]
        public void CreatesAValidRequest()
        {
            var creditcard = _fakes.BraspagCreditcardPayment();
            var request = creditcard.BraspagRequest() as CreditCardDataRequest;
            Assert.AreEqual(10065, request.Amount);
            Assert.AreEqual("Joe Doe", request.CardHolder);
            Assert.AreEqual("5151515151515151", request.CardNumber);
            Assert.AreEqual("05/2018", request.CardExpirationDate);
            Assert.AreEqual("123", request.CardSecurityCode);
        }

        private static List<ValidationResult> CreateValidationResults(BraspagCreditcardPayment creditcard, out bool result)
        {
            var validationResults = new List<ValidationResult>();
            result = Validator.TryValidateObject(creditcard, new ValidationContext(creditcard), validationResults, true);
            return validationResults;
        }

        private static void AssertInvalidResult(bool result, IList<ValidationResult> validationResults)
        {
            Assert.IsFalse(result);
            Assert.AreEqual(1, validationResults.Count);
            var error = validationResults[0];
            Assert.AreEqual("Data de expiração do cartão inválida", error.ErrorMessage);
            Assert.AreEqual(1, error.MemberNames.Count());
            Assert.AreEqual("ExpirationDate", error.MemberNames.ElementAt(0));
        }
    }
}
