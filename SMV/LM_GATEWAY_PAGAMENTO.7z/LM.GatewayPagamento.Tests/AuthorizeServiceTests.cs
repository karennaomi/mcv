﻿using LM.GatewayPagamento.Service.Data.EntityFramework;
using LM.GatewayPagamento.Service.Models.Order;
using LM.GatewayPagamento.Service.Services;
using LM.GatewayPagamento.Service.Services.PaymentGateway;
using NUnit.Framework;

namespace LM.GatewayPagamento.Tests
{
    [TestFixture]
    public class AuthorizeServiceTests
    {
        private readonly Fakes _fakes;

        public AuthorizeServiceTests()
        {
            _fakes = new Fakes();
        }

        #region BRASPAG
        [Test]
        public void TransacaoAutorizada()
        {
            var request = _fakes.BraspagOrderResquest("0000000000000001");
            var response = GetResponse(request);
            Assert.IsTrue(response.IsSuccess);
            Assert.AreEqual(request.AppOrderId, response.Request.AppOrderId);
            Assert.AreEqual(request.Id, response.Request.Id);
            Assert.IsInstanceOf<BraspagOrderResponsePaymentCreditcard>(response.Payment);
            var creditcardResponse = response.Payment as BraspagOrderResponsePaymentCreditcard;
            Assert.AreEqual("6", creditcardResponse.ReturnCode);
            Assert.AreEqual(request.Payment.Amount, response.Payment.Amount);
        }

        [Test]
        public void TransacaoNaoAutorizada()
        {
            var response = GetResponse(_fakes.BraspagOrderResquest("0000000000000002"));
            Assert.IsFalse(response.IsSuccess);
            Assert.IsInstanceOf<BraspagOrderResponsePaymentCreditcard>(response.Payment);
            var creditcardResponse = response.Payment as BraspagOrderResponsePaymentCreditcard;
            Assert.AreEqual("2", creditcardResponse.ReturnCode);
            Assert.AreEqual("Not Authorized", creditcardResponse.ReturnMessage);
        }

        [Test]
        public void TransacaoCartaoCancelado()
        {
            var response = GetResponse(_fakes.BraspagOrderResquest("0000000000000007"));
            Assert.IsFalse(response.IsSuccess);
            Assert.IsInstanceOf<BraspagOrderResponsePaymentCreditcard>(response.Payment);
            var creditcardResponse = response.Payment as BraspagOrderResponsePaymentCreditcard;
            Assert.AreEqual("77", creditcardResponse.ReturnCode);
            Assert.AreEqual("Card Canceled", creditcardResponse.ReturnMessage);
        }

        [Test]
        public void TransacaoProblemasCartaoCredito()
        {
            var response = GetResponse(_fakes.BraspagOrderResquest("0000000000000008"));
            Assert.IsFalse(response.IsSuccess);
            Assert.IsInstanceOf<BraspagOrderResponsePaymentCreditcard>(response.Payment);
            var creditcardResponse = response.Payment as BraspagOrderResponsePaymentCreditcard;
            Assert.AreEqual("70", creditcardResponse.ReturnCode);
            Assert.AreEqual("Problems with Creditcard", creditcardResponse.ReturnMessage);
        }

        [Test]
        public void TransacaoCartaoBloqueado()
        {
            var response = GetResponse(_fakes.BraspagOrderResquest("0000000000000005"));
            Assert.IsFalse(response.IsSuccess);
            Assert.IsInstanceOf<BraspagOrderResponsePaymentCreditcard>(response.Payment);
            var creditcardResponse = response.Payment as BraspagOrderResponsePaymentCreditcard;
            Assert.AreEqual("78", creditcardResponse.ReturnCode);
            Assert.AreEqual("Blocked Card", creditcardResponse.ReturnMessage);
        }

        [Test]
        public void TransacaoCartaoExpirado()
        {
            var response = GetResponse(_fakes.BraspagOrderResquest("0000000000000003"));
            Assert.IsFalse(response.IsSuccess);
            Assert.IsInstanceOf<BraspagOrderResponsePaymentCreditcard>(response.Payment);
            var creditcardResponse = response.Payment as BraspagOrderResponsePaymentCreditcard;
            Assert.AreEqual("57", creditcardResponse.ReturnCode);
            Assert.AreEqual("Card Expired", creditcardResponse.ReturnMessage);
        }

        private static OrderResponse GetResponse(OrderRequest request)
        {
            var service = new AuthorizeService(new BraspagGateway(), new UnitOfWorkEF());
            return service.Authorize(request);
        }
        #endregion

    }

    

}
