﻿using System;
using System.ComponentModel.DataAnnotations;
using LM.GatewayPagamento.Service.Braspag.Pagador.Service;
using LM.GatewayPagamento.Service.Models.Enum;

namespace LM.GatewayPagamento.Service.Models.Payment
{
    public class BraspagCreditcardPayment : OrderRequestPaymentCreditcard, IBraspagPayment
    {
        public BraspagCreditcardPayment(CreditcardType creditcardType)
        {
            BraspagPaymentMethod = GetPaymentMethod(creditcardType);
        }

        private const string Currency = "BRL";
        private const string Country = "BRA";
        private const string ExpirationDateRegex = "\\b(0[1-9]|1[0-2])\\/([0-9]{4})\\b";
        private const string ExpirationDateErrorMessage = "Data de expiração do cartão inválida";

        /// <summary>
        /// Format Example 05/2018
        /// </summary>
        [RegularExpression(ExpirationDateRegex, ErrorMessage = ExpirationDateErrorMessage)]
        public override string ExpirationDate { get; set; }
        public BraspagPaymentMethod BraspagPaymentMethod { get; set; } 
        public PaymentDataRequest BraspagRequest()
        {
            return new CreditCardDataRequest
            {
                PaymentMethod = (short)BraspagPaymentMethod,
                Amount = Helper.ConvertAmountToLong(Amount),
                Currency = Currency,
                Country = Country,
                NumberOfPayments = 1,
                PaymentPlan = 0, //À Vista
                TransactionType = 2, //Captura Automática
                CardHolder = CardHolder,
                CardNumber = CardNumber,
                CardSecurityCode = SecurityCode,
                CardExpirationDate = ExpirationDate, //MM/yyyy
            };
        }

        private static BraspagPaymentMethod GetPaymentMethod(CreditcardType creditcardType)
        {
            switch (creditcardType)
            {
                case CreditcardType.Visa:
                    return BraspagPaymentMethod.CieloVisa;
                case CreditcardType.Mastercard:
                    return BraspagPaymentMethod.CieloMastercard;
                case CreditcardType.Amex:
                    return BraspagPaymentMethod.CieloAmex;
                case CreditcardType.Diners:
                    return BraspagPaymentMethod.CieloDiners;
                case CreditcardType.Elo:
                    return BraspagPaymentMethod.CieloElo;
                case CreditcardType.Simulado:
                    return BraspagPaymentMethod.Simulado;
                default: throw new ApplicationException(string.Format("Invalid creditcard type ({0}).", creditcardType));

            }
        }
    }
}