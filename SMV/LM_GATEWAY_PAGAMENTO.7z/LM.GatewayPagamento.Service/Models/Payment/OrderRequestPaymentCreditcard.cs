﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LM.GatewayPagamento.Service.Models.Payment
{
    public abstract class OrderRequestPaymentCreditcard : OrderRequestPayment
    {
        //Não mapear estas propriedades pois não devemos guardar essas informações por segurança

        [NotMapped]
        public string CardHolder { get; set; }
        [NotMapped]
        public string CardNumber { get; set; }
        [NotMapped]
        public string SecurityCode { get; set; }
        [NotMapped]
        public virtual string ExpirationDate { get; set; }
    }
}