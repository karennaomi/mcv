﻿using LM.GatewayPagamento.Service.Braspag.Pagador.Service;
using LM.GatewayPagamento.Service.Models.Enum;

namespace LM.GatewayPagamento.Service.Models.Payment
{
    public interface IBraspagPayment
    {
        BraspagPaymentMethod BraspagPaymentMethod { get; set; }
        PaymentDataRequest BraspagRequest();
    }
}