﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace LM.GatewayPagamento.Service.Models.Payment
{
    [Table("OrderRequestPayments")]
    public abstract class OrderRequestPayment
    {
        protected OrderRequestPayment()
        {
            Id = Guid.NewGuid();
        }

        public Guid Id { get; set; }
        public decimal Amount { get; set; }
    }
}