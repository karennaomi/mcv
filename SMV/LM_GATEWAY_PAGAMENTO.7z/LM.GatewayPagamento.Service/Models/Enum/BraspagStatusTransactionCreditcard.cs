﻿
namespace LM.GatewayPagamento.Service.Models.Enum
{
    public enum BraspagStatusTransactionCreditcard : byte
    {
        Capturado = 0,
        Autorizada = 1,
        NaoAutorizada = 2,
        ErroDesqualificante = 3,
        AguardandoResposta = 4
    }
}