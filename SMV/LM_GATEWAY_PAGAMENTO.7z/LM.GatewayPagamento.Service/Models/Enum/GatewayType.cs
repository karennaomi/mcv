﻿
namespace LM.GatewayPagamento.Service.Models.Enum
{
    public enum GatewayType
    {
        Braspag
    }
}