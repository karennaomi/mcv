﻿namespace LM.GatewayPagamento.Service.Models.Enum
{
    public enum BraspagPaymentMethod : short
    {
        CieloVisa = 500,
        CieloMastercard = 501,
        CieloAmex = 502,
        CieloDiners = 503,
        CieloElo = 504,
        Simulado = 997
    }
}