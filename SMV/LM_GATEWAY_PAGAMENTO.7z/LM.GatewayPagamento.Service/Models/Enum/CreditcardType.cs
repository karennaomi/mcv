﻿
namespace LM.GatewayPagamento.Service.Models.Enum
{
    public enum CreditcardType
    {
        Visa, Mastercard, Amex, Diners, Elo, Simulado
    }
}