﻿using System;
using LM.GatewayPagamento.DTO;
using LM.GatewayPagamento.Service.Models.Enum;
using LM.GatewayPagamento.Service.Models.Order;
using LM.GatewayPagamento.Service.Models.Payment;

namespace LM.GatewayPagamento.Service.Models
{
    public class Helper
    {
        public static long ConvertAmountToLong(decimal amount)
        {
            return (long)(amount*100);
        }

        public static decimal ConvertAmountToDecimal(long amount)
        {
            return (decimal)(amount / 100.0);
        }

        public static OrderRequest GetOrderRequestFromDTO(PaymentRequestDTO requestDTO)
        {
            GatewayType type;
            if (!System.Enum.TryParse(requestDTO.GatewayType, true, out type)) throw new ApplicationException(string.Format("Invalid gateway type ({0}).", requestDTO.GatewayType));

            switch (type)
            {
                case GatewayType.Braspag: return GetBraspagOrderRequest(requestDTO);
                default: throw new ApplicationException(string.Format("Invalid gateway type ({0}).", requestDTO.GatewayType));
            }
        }

        private static OrderRequest GetBraspagOrderRequest(PaymentRequestDTO requestDTO)
        {
            CreditcardType type;
            if(!System.Enum.TryParse(requestDTO.CreditcardType, true, out type)) throw new ApplicationException(string.Format("Invalid creditcard type ({0}).", requestDTO.CreditcardType));

            return new BraspagOrderRequest
            {
                CustomerDocument = requestDTO.CustomerDocument,
                CustomerName = requestDTO.CustomerName,
                AppName = requestDTO.AppName,
                AppOrderId = requestDTO.AppOrderId,
                Payment = new BraspagCreditcardPayment(type)
                {
                    Amount = requestDTO.Amount,
                    CardHolder = requestDTO.CardHolder,
                    CardNumber = requestDTO.CardNumber,
                    ExpirationDate = requestDTO.ExpirationDate,
                    SecurityCode = requestDTO.SecurityCode
                }
            };
        }
    }
}