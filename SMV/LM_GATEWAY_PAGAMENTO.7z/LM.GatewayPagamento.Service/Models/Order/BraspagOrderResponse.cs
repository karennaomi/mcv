﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using LM.GatewayPagamento.Service.Braspag.Pagador.Service;

namespace LM.GatewayPagamento.Service.Models.Order
{
    [Table("BraspagOrderResponses")]
    public class BraspagOrderResponse : OrderResponse
    {
        public Guid BraspagOrderId { get; set; }

        public BraspagOrderResponse() { }
        public BraspagOrderResponse(AuthorizeTransactionResponse response)
        {
            IsSuccess = response.Success && CheckPayment(response);
            if(IsSuccess)
            {
                BraspagOrderId = response.OrderData.BraspagOrderId;
            }
            else
            {
                Errors = response.ErrorReportDataCollection.Select(e => new BraspagOrderResponseError(e)).Cast<OrderResponseError>().ToList();
            }
        }

        private bool CheckPayment(AuthorizeTransactionResponse response)
        {
            if (response.PaymentDataCollection == null || !response.PaymentDataCollection.Any()) return false;
            var payment = response.PaymentDataCollection.First();
            if (!(payment is CreditCardDataResponse)) return false;
            
            var creditcardPayment = payment as CreditCardDataResponse;
            Payment = new BraspagOrderResponsePaymentCreditcard(creditcardPayment);
            return creditcardPayment.ReturnCode == "6";
        }
    }
}