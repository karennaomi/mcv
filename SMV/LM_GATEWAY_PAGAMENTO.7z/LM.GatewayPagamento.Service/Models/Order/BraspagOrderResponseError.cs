﻿
namespace LM.GatewayPagamento.Service.Models.Order
{
    public class BraspagOrderResponseError : OrderResponseError
    {
        public BraspagOrderResponseError() { }
        public BraspagOrderResponseError(Braspag.Pagador.Service.ErrorReportDataResponse e)
        {
            ErrorCode = e.ErrorCode;
            ErrorMessage = e.ErrorMessage;
        }
    }
}