﻿using System.ComponentModel.DataAnnotations.Schema;
using LM.GatewayPagamento.Service.Models.Enum;

namespace LM.GatewayPagamento.Service.Models.Order
{
    [Table("BraspagOrderResponsePaymentCreditcards")]
    public class BraspagOrderResponsePaymentCreditcard : BraspagOrderResponsePayment
    {
        public string AcquirerTransactionId { get; set; }
        public string AuthorizationCode { get; set; }
        public string ReturnCode { get; set; }
        public string ReturnMessage { get; set; }
        public string ProofOfSale { get; set; }
        public BraspagStatusTransactionCreditcard StatusTransactionCreditcard { get; set; }

        public BraspagOrderResponsePaymentCreditcard() { }

        public BraspagOrderResponsePaymentCreditcard(Braspag.Pagador.Service.CreditCardDataResponse payment) : base(payment)
        {
            AcquirerTransactionId = payment.AcquirerTransactionId;
            AuthorizationCode = payment.AuthorizationCode;
            ReturnCode = payment.ReturnCode;
            ReturnMessage = payment.ReturnMessage;
            ProofOfSale = payment.ProofOfSale;
            StatusTransactionCreditcard = (BraspagStatusTransactionCreditcard)payment.Status;
        }
    }
}