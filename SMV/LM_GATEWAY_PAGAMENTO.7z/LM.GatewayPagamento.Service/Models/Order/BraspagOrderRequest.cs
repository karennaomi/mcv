﻿
namespace LM.GatewayPagamento.Service.Models.Order
{
    public class BraspagOrderRequest : OrderRequest
    {
    }
}