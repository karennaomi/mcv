﻿
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace LM.GatewayPagamento.Service.Models.Order
{
    [Table("OrderResponseErrors")]
    public abstract class OrderResponseError
    {
        protected OrderResponseError()
        {
            Id = Guid.NewGuid();
        }
        public Guid Id { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
    }
}