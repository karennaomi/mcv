﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace LM.GatewayPagamento.Service.Models.Order
{
    [Table("OrderResponses")]
    public abstract class OrderResponse
    {
        protected OrderResponse()
        {
            Id = Guid.NewGuid();
            CreatedAt = UpdatedAt = DateTime.Now;
        }

        public Guid Id { get; set; }
        public bool IsSuccess { get; set; }
        public virtual OrderRequest Request { get; set; }
        public virtual ICollection<OrderResponseError> Errors { get; set; }
        public virtual OrderResponsePayment Payment { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}