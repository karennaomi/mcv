﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace LM.GatewayPagamento.Service.Models.Order
{
    [Table("BraspagOrderResponsePayments")]
    public abstract class BraspagOrderResponsePayment : OrderResponsePayment
    {
        public Guid TransactionId { get; set; }
        public short PaymentMethod { get; set; }

        protected BraspagOrderResponsePayment() { }
        protected BraspagOrderResponsePayment(Braspag.Pagador.Service.PaymentDataResponse payment)
        {
            Amount = Helper.ConvertAmountToDecimal(payment.Amount);
            TransactionId = payment.BraspagTransactionId;
            PaymentMethod = payment.PaymentMethod;
        }
        
    }
}
