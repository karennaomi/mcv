using System;
using System.ComponentModel.DataAnnotations.Schema;
using LM.GatewayPagamento.Service.Models.Payment;

namespace LM.GatewayPagamento.Service.Models.Order
{
    [Table("OrderRequests")]
    public abstract class OrderRequest
    {
        protected OrderRequest()
        {
            Id = Guid.NewGuid();
            CreatedAt = UpdatedAt = DateTime.Now;
        }

        public Guid Id { get; set; }
        public string AppName { get; set; }
        public int AppOrderId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerDocument { get; set; }
        public virtual OrderRequestPayment Payment { get; set; }
        public virtual OrderResponse Response { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}