﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace LM.GatewayPagamento.Service.Models.Order
{
    [Table("OrderResponsePayments")]
    public abstract class OrderResponsePayment
    {
        protected OrderResponsePayment()
        {
            Id = Guid.NewGuid();
        }

        public Guid Id { get; set; }
        public decimal Amount { get; set; }
    }
}
