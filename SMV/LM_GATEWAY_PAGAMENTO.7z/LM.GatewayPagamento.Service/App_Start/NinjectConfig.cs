﻿using LM.GatewayPagamento.Service.Data.EntityFramework;
using LM.GatewayPagamento.Service.Data.Repository;
using LM.GatewayPagamento.Service.Services;
using LM.GatewayPagamento.Service.Services.PaymentGateway;
using Ninject;
using System.Reflection;

namespace LM.GatewayPagamento.Service.App_Start
{
    public class NinjectConfig
    {
        public static StandardKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());
            RegisterBinds(kernel);
            return kernel;
        }

        private static void RegisterBinds(StandardKernel kernel)
        {
            kernel.Bind<IAuthorizeService>().To<AuthorizeService>();
            kernel.Bind<IPaymentGateway>().To<BraspagGateway>();
            kernel.Bind<IUnitOfWork>().To<UnitOfWorkEF>();
        }
    }
}