﻿using LM.GatewayPagamento.Service.Models.Order;

namespace LM.GatewayPagamento.Service.Data.Repository
{
    public interface IOrderResponseRepository : IRepository<OrderResponse>
    {
    }
}