﻿namespace LM.GatewayPagamento.Service.Data.Repository
{
    public interface IUnitOfWork
    {
        IOrderRequestRepository OrderRequestRepository { get; }
        IOrderResponseRepository OrderResponseRepository { get; }
        void Save();
    }
}