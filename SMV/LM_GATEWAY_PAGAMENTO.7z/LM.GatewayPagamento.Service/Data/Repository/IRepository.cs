﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace LM.GatewayPagamento.Service.Data.Repository
{
    public interface IRepository<T>
    {
        T Get(Guid id);
        T Create(T entity);
        IEnumerable<T> Search(Expression<Func<T, bool>> filter = null);
    }
}
