﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LM.GatewayPagamento.Service.Data.Repository;

namespace LM.GatewayPagamento.Service.Data.EntityFramework
{
    public abstract class GenericEFDataAccess<T> : IRepository<T> where T : class
    {
        internal readonly GatewayPagamentoContext Context;
        internal DbSet<T> DbSet;
        protected GenericEFDataAccess(GatewayPagamentoContext context)
        {
            Context = context;
            DbSet = context.Set<T>();
        }

        public virtual T Get(Guid id)
        {
            return DbSet.Find(id);
        }

        public virtual T Create(T entity)
        {
            return DbSet.Add(entity);
        }

        public virtual IEnumerable<T> Search(Expression<Func<T, bool>> filter = null)
        {
            IQueryable<T> query = DbSet;
            if (filter != null) query = query.Where(filter);
            return query.ToList();
        }
    }
}