﻿using LM.GatewayPagamento.Service.Models.Order;
using System.Data.Entity;
using LM.GatewayPagamento.Service.Models.Payment;

namespace LM.GatewayPagamento.Service.Data.EntityFramework
{
    public class GatewayPagamentoContext : DbContext
    {
        public DbSet<OrderRequest> OrderRequests { get; set; }
        public DbSet<OrderRequestPayment> Payments { get; set; }
        public DbSet<OrderResponse> OrderResponses { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OrderResponse>().HasRequired(r => r.Request).WithOptional(r => r.Response).WillCascadeOnDelete(true);
            modelBuilder.Entity<OrderResponse>().HasMany(r => r.Errors).WithRequired().WillCascadeOnDelete(true);
            base.OnModelCreating(modelBuilder);
        }
    }
}