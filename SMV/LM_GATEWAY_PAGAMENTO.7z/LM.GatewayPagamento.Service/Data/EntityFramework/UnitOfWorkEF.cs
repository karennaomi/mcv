﻿using LM.GatewayPagamento.Service.Data.Repository;
using System;

namespace LM.GatewayPagamento.Service.Data.EntityFramework
{
    public class UnitOfWorkEF : IUnitOfWork, IDisposable
    {
        private readonly GatewayPagamentoContext _context = new GatewayPagamentoContext();
        private IOrderRequestRepository _orderRequestRepo;
        private IOrderResponseRepository _orderResponseRepo;

        public IOrderRequestRepository OrderRequestRepository
        {
            get { return _orderRequestRepo ?? (_orderRequestRepo = new OrderRequestEF(_context)); }
        }

        public IOrderResponseRepository OrderResponseRepository
        {
            get { return _orderResponseRepo ?? (_orderResponseRepo = new OrderResponseEF(_context)); }
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        private bool _disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            _disposed = true;
        }
        
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}