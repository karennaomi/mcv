﻿
using LM.GatewayPagamento.Service.Data.Repository;
using LM.GatewayPagamento.Service.Models.Order;

namespace LM.GatewayPagamento.Service.Data.EntityFramework
{
    public class OrderResponseEF : GenericEFDataAccess<OrderResponse>, IOrderResponseRepository
    {
        public OrderResponseEF(GatewayPagamentoContext context) : base(context) { }
    }
}