﻿using LM.GatewayPagamento.Service.Data.Repository;
using LM.GatewayPagamento.Service.Models.Order;

namespace LM.GatewayPagamento.Service.Data.EntityFramework
{
    public class OrderRequestEF : GenericEFDataAccess<OrderRequest>, IOrderRequestRepository
    {
        public OrderRequestEF(GatewayPagamentoContext context) : base(context) { }
    }
}