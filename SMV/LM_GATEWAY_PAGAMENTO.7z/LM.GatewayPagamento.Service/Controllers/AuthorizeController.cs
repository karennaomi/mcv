﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using LM.GatewayPagamento.DTO;
using LM.GatewayPagamento.Service.Models;
using LM.GatewayPagamento.Service.Services;

namespace LM.GatewayPagamento.Service.Controllers
{
    public class AuthorizeController : ApiController
    {
        private readonly IAuthorizeService _authorizeService;
        public AuthorizeController(IAuthorizeService authorizeService)
        {
            _authorizeService = authorizeService;
        }

        public string Get()
        {
            return "LM.GatewayPagamento Authorize endpoint.";
        }

        public string Get(string id)
        {
            return "Authorization " + id;
        }

        public void Post(PaymentRequestDTO requestDTO)
        {
            var response = _authorizeService.Authorize(Helper.GetOrderRequestFromDTO(requestDTO));
            if (!response.IsSuccess) throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.BadRequest)); 
        }
    }
}