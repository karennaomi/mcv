﻿using LM.GatewayPagamento.Service.Data.Repository;
using LM.GatewayPagamento.Service.Models.Order;
using LM.GatewayPagamento.Service.Services.PaymentGateway;

namespace LM.GatewayPagamento.Service.Services
{
    public interface IAuthorizeService
    {
        OrderResponse Authorize(OrderRequest orderRequest);
    }

    public class AuthorizeService: IAuthorizeService
    {
        private readonly IPaymentGateway _gateway;
        private readonly IUnitOfWork _unitOfWork;
        public AuthorizeService(IPaymentGateway gateway, IUnitOfWork unitOfWork)
        {
            _gateway = gateway;
            _unitOfWork = unitOfWork;
        }

        public OrderResponse Authorize(OrderRequest orderRequest)
        {
            _unitOfWork.OrderRequestRepository.Create(orderRequest);
            var response = _gateway.AuthorizeTransaction(orderRequest);
            response = _unitOfWork.OrderResponseRepository.Create(response);
            _unitOfWork.Save();
            return response;
        }
    }
}