﻿
using LM.GatewayPagamento.Service.Models.Order;

namespace LM.GatewayPagamento.Service.Services.PaymentGateway
{
    public interface IPaymentGateway
    {
        OrderResponse AuthorizeTransaction(OrderRequest order);
        void CaptureTransaction();
        void CancelTransaction();
        void RefundTransaction();
    }
}
