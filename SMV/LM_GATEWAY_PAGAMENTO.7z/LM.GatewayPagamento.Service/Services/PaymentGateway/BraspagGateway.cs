﻿using System;
using System.Configuration;
using LM.GatewayPagamento.Service.Braspag.Pagador.Service;
using LM.GatewayPagamento.Service.Models.Order;
using LM.GatewayPagamento.Service.Models.Payment;

namespace LM.GatewayPagamento.Service.Services.PaymentGateway
{
    public class BraspagGateway : IPaymentGateway
    {
        private const string WebServiceVersion = "1.0";
        
        private readonly PagadorTransactionSoapClient _pagadorClient;
        private readonly Guid _pagadorMerchantId;

        public BraspagGateway()
        {
            _pagadorClient = new PagadorTransactionSoapClient();
            _pagadorMerchantId = Guid.Parse(ConfigurationManager.AppSettings["BraspagPagadorMerchantId"]);
        }

        public OrderResponse AuthorizeTransaction(OrderRequest orderRequest)
        {
            if(!(orderRequest.Payment is IBraspagPayment)) throw new ApplicationException("Tipo do pagamento inválido.");
            var payment = orderRequest.Payment as IBraspagPayment;
            var orderResponse = _pagadorClient.AuthorizeTransaction(new AuthorizeTransactionRequest
            {
                RequestId = orderRequest.Id,
                Version = WebServiceVersion,
                OrderData = new OrderDataRequest
                {
                    MerchantId = _pagadorMerchantId,
                    OrderId = orderRequest.AppOrderId.ToString()
                },
                PaymentDataCollection = new[] { payment.BraspagRequest() },
                CustomerData = new CustomerDataRequest
                {
                    CustomerIdentity = orderRequest.CustomerDocument,
                    CustomerName = orderRequest.CustomerName
                }
            });

            var braspagOrderResponse = new BraspagOrderResponse(orderResponse) {Request = orderRequest};
            return braspagOrderResponse;
        }

        public void CaptureTransaction()
        {
            throw new NotImplementedException();
        }

        public void CancelTransaction()
        {
            throw new NotImplementedException();
        }

        public void RefundTransaction()
        {
            throw new NotImplementedException();
        }
    }
}
