﻿using LM.GatewayPagamento.Service.App_Start;
using Microsoft.Owin;
using Ninject.Web.Common.OwinHost;
using Ninject.Web.WebApi.OwinHost;
using Owin;
using System.Web.Http;

[assembly: OwinStartup(typeof(LM.GatewayPagamento.Service.Startup))]

namespace LM.GatewayPagamento.Service
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();

            var kernel = NinjectConfig.CreateKernel();
            app.UseNinjectMiddleware(() => kernel);
            WebApiConfig.Register(config);
            app.UseNinjectWebApi(config);
        }
    }
}
