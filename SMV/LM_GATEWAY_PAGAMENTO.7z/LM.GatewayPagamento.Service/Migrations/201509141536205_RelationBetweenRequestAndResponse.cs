namespace LM.GatewayPagamento.Service.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RelationBetweenRequestAndResponse : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.OrderRequests", "AppName", c => c.String());
            AddColumn("dbo.OrderRequests", "AppOrderId", c => c.Int(nullable: false));
            CreateIndex("dbo.OrderResponses", "Id");
            AddForeignKey("dbo.OrderResponses", "Id", "dbo.OrderRequests", "Id", cascadeDelete: true);
            DropColumn("dbo.OrderRequests", "LMOrderId");
            DropColumn("dbo.OrderResponses", "LMOrderId");
            DropColumn("dbo.OrderResponses", "RequestId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.OrderResponses", "RequestId", c => c.Guid(nullable: false));
            AddColumn("dbo.OrderResponses", "LMOrderId", c => c.Int(nullable: false));
            AddColumn("dbo.OrderRequests", "LMOrderId", c => c.Int(nullable: false));
            DropForeignKey("dbo.OrderResponses", "Id", "dbo.OrderRequests");
            DropIndex("dbo.OrderResponses", new[] { "Id" });
            DropColumn("dbo.OrderRequests", "AppOrderId");
            DropColumn("dbo.OrderRequests", "AppName");
        }
    }
}
