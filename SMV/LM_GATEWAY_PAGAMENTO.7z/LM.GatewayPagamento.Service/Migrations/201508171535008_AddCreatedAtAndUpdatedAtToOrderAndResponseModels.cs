namespace LM.GatewayPagamento.Service.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddCreatedAtAndUpdatedAtToOrderAndResponseModels : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.OrderRequests", "CreatedAt", c => c.DateTime(nullable: false));
            AddColumn("dbo.OrderRequests", "UpdatedAt", c => c.DateTime(nullable: false));
            AddColumn("dbo.OrderResponses", "CreatedAt", c => c.DateTime(nullable: false));
            AddColumn("dbo.OrderResponses", "UpdatedAt", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.OrderResponses", "UpdatedAt");
            DropColumn("dbo.OrderResponses", "CreatedAt");
            DropColumn("dbo.OrderRequests", "UpdatedAt");
            DropColumn("dbo.OrderRequests", "CreatedAt");
        }
    }
}
