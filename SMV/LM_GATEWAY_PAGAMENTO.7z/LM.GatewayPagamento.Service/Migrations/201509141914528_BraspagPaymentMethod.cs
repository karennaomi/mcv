namespace LM.GatewayPagamento.Service.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class BraspagPaymentMethod : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.OrderRequestPayments", "BraspagPaymentMethod", c => c.Short());
            DropColumn("dbo.OrderRequestPayments", "PaymentMethod");
        }
        
        public override void Down()
        {
            AddColumn("dbo.OrderRequestPayments", "PaymentMethod", c => c.Short(nullable: false));
            DropColumn("dbo.OrderRequestPayments", "BraspagPaymentMethod");
        }
    }
}
