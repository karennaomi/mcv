namespace LM.GatewayPagamento.Service.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FirstMigration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.OrderRequests",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        LMOrderId = c.Int(nullable: false),
                        CustomerName = c.String(),
                        CustomerDocument = c.String(),
                        Payment_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.OrderRequestPayments", t => t.Payment_Id)
                .Index(t => t.Payment_Id);
            
            CreateTable(
                "dbo.OrderRequestPayments",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        PaymentMethod = c.Short(nullable: false),
                        Amount = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.OrderResponses",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        IsSuccess = c.Boolean(nullable: false),
                        LMOrderId = c.Int(nullable: false),
                        RequestId = c.Guid(nullable: false),
                        Payment_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.OrderResponsePayments", t => t.Payment_Id)
                .Index(t => t.Payment_Id);
            
            CreateTable(
                "dbo.OrderResponseErrors",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        ErrorCode = c.String(),
                        ErrorMessage = c.String(),
                        OrderResponse_Id = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.OrderResponses", t => t.OrderResponse_Id, cascadeDelete: true)
                .Index(t => t.OrderResponse_Id);
            
            CreateTable(
                "dbo.OrderResponsePayments",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Amount = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.BraspagOrderResponsePayments",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        TransactionId = c.Guid(nullable: false),
                        PaymentMethod = c.Short(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.OrderResponsePayments", t => t.Id)
                .Index(t => t.Id);
            
            CreateTable(
                "dbo.BraspagOrderResponsePaymentCreditcards",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        AcquirerTransactionId = c.String(),
                        AuthorizationCode = c.String(),
                        ReturnCode = c.String(),
                        ReturnMessage = c.String(),
                        ProofOfSale = c.String(),
                        StatusTransactionCreditcard = c.Byte(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.BraspagOrderResponsePayments", t => t.Id)
                .Index(t => t.Id);
            
            CreateTable(
                "dbo.BraspagOrderResponses",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        BraspagOrderId = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.OrderResponses", t => t.Id)
                .Index(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.BraspagOrderResponses", "Id", "dbo.OrderResponses");
            DropForeignKey("dbo.BraspagOrderResponsePaymentCreditcards", "Id", "dbo.BraspagOrderResponsePayments");
            DropForeignKey("dbo.BraspagOrderResponsePayments", "Id", "dbo.OrderResponsePayments");
            DropForeignKey("dbo.OrderResponses", "Payment_Id", "dbo.OrderResponsePayments");
            DropForeignKey("dbo.OrderResponseErrors", "OrderResponse_Id", "dbo.OrderResponses");
            DropForeignKey("dbo.OrderRequests", "Payment_Id", "dbo.OrderRequestPayments");
            DropIndex("dbo.BraspagOrderResponses", new[] { "Id" });
            DropIndex("dbo.BraspagOrderResponsePaymentCreditcards", new[] { "Id" });
            DropIndex("dbo.BraspagOrderResponsePayments", new[] { "Id" });
            DropIndex("dbo.OrderResponseErrors", new[] { "OrderResponse_Id" });
            DropIndex("dbo.OrderResponses", new[] { "Payment_Id" });
            DropIndex("dbo.OrderRequests", new[] { "Payment_Id" });
            DropTable("dbo.BraspagOrderResponses");
            DropTable("dbo.BraspagOrderResponsePaymentCreditcards");
            DropTable("dbo.BraspagOrderResponsePayments");
            DropTable("dbo.OrderResponsePayments");
            DropTable("dbo.OrderResponseErrors");
            DropTable("dbo.OrderResponses");
            DropTable("dbo.OrderRequestPayments");
            DropTable("dbo.OrderRequests");
        }
    }
}
