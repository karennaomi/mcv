﻿namespace LM.GatewayPagamento.DTO
{
    public class PaymentRequestDTO
    {
        public string GatewayType { get; set; }
        public string AppName { get; set; }
        public int AppOrderId { get; set; }
        public string CustomerDocument { get; set; }
        public string CustomerName { get; set; }
        public string CreditcardType { get; set; } 
        public string CardHolder { get; set; }
        public string CardNumber { get; set; }
        public decimal Amount { get; set; }
        public string ExpirationDate { get; set; }
        public string SecurityCode { get; set; }
    }
}