<?php include('inc/header.php') ?>
<article class="modal fade show in modal-cadastro" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content modal-pj">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    (X) Fechar
                </button>
                <img src="assets/img/logo.png" height="20" />
                <h1>Pagamento Via Cartão de Crédito <small>3 de 5</small></h1>
            </div>
            <div class="modal-body">
                <div class="alert alert-success">
                    Pagamento realizado com sucesso!
                </div>
                <form class="cadastro-form">
                    <input type="submit" value="Proxima Etapa" class="btn btn-lg btn-pj" />
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</article><!-- /.modal -->

</body>
</html>
