<!DOCTYPE html>
<html>
    <head>
        <title>Contador Virtual</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
        <link href="assets/css/layout.css" rel="stylesheet" />
        <script src="assets/js/jquery.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.mask.js"></script>
        <!--<script src="assets/js/init.js"></script>-->
    </head>
    <body>