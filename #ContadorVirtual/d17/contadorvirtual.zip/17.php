<?php include('inc/header.php') ?>
<article class="modal fade show in modal-cadastro" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content modal-pj">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    (X) Fechar
                </button>
                <img src="assets/img/logo.png" height="20" />
                <h1>Informações Finais <small>5 de 5</small></h1>
            </div>
            <div class="modal-body">
                <p>
                    Este último processo levará alguns minutos e é constituido das seguintes etapas:
                </p>
                <ul class="cadastro-steps steps-sm clearfix">
                    <li class="done">
                        Dados dos sócios
                    </li>
                    <li class="done">
                        Dados da Folha de Pagamento
                    </li>
                    <li class="done">
                        Inscrição
                        Municipal
                    </li>
                    <li class="done">
                        Dados de acesso
                    </li>
                    <li class="done">
                        Anexar
                        Contrato Social
                    </li>
                </ul>
                <form class="cadastro-form">
                    <fieldset>
                        <legend>Imprimir Documento</legend>
                        <p>
                            Agora imprima este documento	, que deverá ser assinado pelo seu antigo contador e
                            envie por correios para XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                        </p>
                        <a href="#" class="btn btn-pf">Imprimir</a>
                        <a href="#" class="btn btn-pf">Salvar em PDF</a>
                    </fieldset>
                    <hr class="invisible" />
                    <input type="submit" value="Avançar" class="btn btn-lg btn-pj" />
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</article><!-- /.modal -->

</body>
</html>
