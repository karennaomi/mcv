<?php include('inc/header.php') ?>
        <article class="modal fade show in modal-cadastro" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            (X) Fechar
                        </button>
                        <img src="assets/img/logo.png" />
                    </div>
                    <div class="modal-body">
                        <div class="cadastro-titles">
                            <h1>Bem vindo ao Meu Contador Virtual!</h1>
                            <p>
                                Nas próximas telas iremos dar início ao seu cadastro.
                            </p>
                        </div>
                        <a href="#" class="btn btn-lg btn-pf">Cadastro Pessoa Física</a>
                        <a href="#" class="btn btn-lg btn-pj">Cadastro Pessoa Jurídica</a>
                        <div>
                            <a href="#" class="btn btn-link btn-cancelar">> Cancelar</a>
                        </div>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </article><!-- /.modal -->
        
    </body>
</html>
