<?php include('inc/header.php') ?>
<article class="modal fade show in modal-cadastro" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content modal-pf">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    (X) Fechar
                </button>
                <img src="assets/img/logo.png" height="20" />
                <h1>Cadastro Pessoa Física</h1>
            </div>
            <div class="modal-body">
                <form class="cadastro-form">
                    <label class="center-block">
                        Nome Completo:
                        <input type="text" class="form-control" />
                    </label>
                    <label class="center-block">
                        E-mail de Contato:
                        <input type="email" class="form-control" />
                    </label>
                    <label class="center-block">
                        CPF:
                        <input type="text" class="form-control" />
                    </label>
                    <div class="row">
                        <div class="col-sm-6">
                            <label class="center-block">
                                Senha:
                                <input type="password" class="form-control" />
                            </label>
                        </div>
                        <div class="col-sm-6">
                            <label class="center-block">
                                Repetir Senha:
                                <input type="password" class="form-control" />
                            </label>
                        </div>
                    </div>
                    <input type="submit" value="Cadastrar" class="btn btn-lg btn-pf" />
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</article><!-- /.modal -->

</body>
</html>
