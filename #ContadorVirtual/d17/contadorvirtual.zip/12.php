<?php include('inc/header.php') ?>
<article class="modal fade show in modal-cadastro" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content modal-pj">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    (X) Fechar
                </button>
                <img src="assets/img/logo.png" height="20" />
                <h1>Informações Finais <small>5 de 5</small></h1>
            </div>
            <div class="modal-body">
                <p>
                    Este último processo levará alguns minutos e é constituido das seguintes etapas:
                </p>
                <ul class="cadastro-steps steps-sm clearfix">
                    <li class="active">
                        Dados dos sócios
                    </li>
                    <li>
                        Dados da Folha de Pagamento
                    </li>
                    <li>
                        Inscrição
                        Municipal
                    </li>
                    <li>
                        Dados de acesso
                    </li>
                    <li>
                        Anexar
                        Contrato Social
                    </li>
                </ul>
                <form class="cadastro-form">
                    <fieldset>
                        <legend class="pull-left">Cadastrar Sócios</legend>
                        <a href="#" class="btn btn-add pull-right">+ adicionar outro sócio</a>
                        <div class="clearfix"></div>
                        <label class="center-block">
                            Nome Completo:
                            <input type="text" class="form-control" />
                        </label>
                        <label class="center-block">
                            Percentual:
                            <input type="text" class="form-control" />
                        </label>
                    </fieldset>
                    <input type="submit" value="Próxima Etapa" class="btn btn-lg btn-pj" />
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</article><!-- /.modal -->

</body>
</html>
