<?php include('inc/header.php') ?>
<article class="modal fade show in modal-cadastro" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content modal-pj">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    (X) Fechar
                </button>
                <img src="assets/img/logo.png" height="20" />
                <h1>Pagamento Via Cartão de Crédito <small>3 de 5</small></h1>
            </div>
            <div class="modal-body">
                <form class="cadastro-form">
                    <div class="radio">
                        <label>
                            <input type="radio" name="card" /> <img src="assets/img/img-visa.png" />
                        </label>
                        <label>
                            <input type="radio" name="card" /> <img src="assets/img/img-mastercard.png" />
                        </label>
                    </div>
                    <label class="center-block">
                        Nome Impresso no Cartão:
                        <input type="text" class="form-control" />
                    </label>
                    <label class="center-block">
                        Número do Cartão:
                        <input type="text" class="form-control" />
                    </label>
                    <div class="row">
                        <div class="col-sm-6">
                            <label class="center-block">
                                Validade:
                                <input type="text" class="form-control" />
                            </label>
                        </div>
                        <div class="col-sm-6">
                            <label class="center-block">
                                Codigo de Segurança:
                                <input type="text" class="form-control" />
                            </label>
                        </div>
                    </div>
                    <label class="center-block">
                        Senha:
                        <input type="password" class="form-control" />
                    </label>
                    <input type="submit" value="Proxima Etapa" class="btn btn-lg btn-pj" />
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</article><!-- /.modal -->

</body>
</html>
