<?php include('inc/header.php') ?>
<article class="modal fade show in modal-cadastro" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content modal-pj">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    (X) Fechar
                </button>
                <img src="assets/img/logo.png" height="20" />
                <h1>Consultar CNPJ <small>2 de 5</small></h1>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger">
                    Prezado, informamos que o CNPJ consultado<br />
                    não está apto para a consulta.
                </div>
                <form class="cadastro-form">
                    <label class="center-block">
                        Informar novo CNPJ:
                        <input type="text" class="form-control" />
                    </label>
                    <input type="submit" value="Consultar Novamente" class="btn btn-lg btn-pj" />
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</article><!-- /.modal -->

</body>
</html>
