<?php include('inc/header.php') ?>
<article class="modal fade show in modal-cadastro" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content modal-pf">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    (X) Fechar
                </button>
                <img src="assets/img/logo.png" height="20" />
                <h1>Cadastro Pessoa Física</h1>
            </div>
            <div class="modal-body">
                <div class="cadastro-titles">
                    <h2>Sucesso!</h2>
                    <p>
                        Seu cadastro foi realizado com sucesso, comece agora mesmo o Meu Contador Virtual.
                    </p>
                </div>
                <a class="btn btn-lg btn-pf">Iniciar</a>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</article><!-- /.modal -->

</body>
</html>
