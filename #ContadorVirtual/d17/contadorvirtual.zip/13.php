<?php include('inc/header.php') ?>
<article class="modal fade show in modal-cadastro" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content modal-pj">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    (X) Fechar
                </button>
                <img src="assets/img/logo.png" height="20" />
                <h1>Informações Finais <small>5 de 5</small></h1>
            </div>
            <div class="modal-body">
                <p>
                    Este último processo levará alguns minutos e é constituido das seguintes etapas:
                </p>
                <ul class="cadastro-steps steps-sm clearfix">
                    <li class="done">
                        Dados dos sócios
                    </li>
                    <li class="active">
                        Dados da Folha de Pagamento
                    </li>
                    <li>
                        Inscrição
                        Municipal
                    </li>
                    <li>
                        Dados de acesso
                    </li>
                    <li>
                        Anexar
                        Contrato Social
                    </li>
                </ul>
                <form class="cadastro-form">
                    <fieldset>
                        <legend class="pull-left">Dados Folha de Pagamento</legend>
                        <div class="clearfix"></div>
                        <label class="center-block">
                            Número de Funcionários:
                            <input type="text" class="form-control" />
                        </label>
                    </fieldset>
                    <input type="submit" value="Próxima Etapa" class="btn btn-lg btn-pj" />
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</article><!-- /.modal -->

</body>
</html>
